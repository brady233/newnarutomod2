package com.shinobiarts;

import net.minecraftforge.common.ForgeConfigSpec;

/**
 * All balance values. This is a SERVER config: it lives in each world's serverconfig folder
 * (saves/WORLD/serverconfig/shinobiarts-server.toml) and Forge sends it to every client that joins,
 * so the HUD and menus always show the same numbers the server uses.
 * Use the b()/i()/d() helpers to read values safely even before a world is loaded.
 */
public final class Config {
    private static final ForgeConfigSpec.Builder B = new ForgeConfigSpec.Builder();

    // ---------------------------------------------------------------- general
    static { B.push("general"); }
    public static final ForgeConfigSpec.BooleanValue JUTSU_GRIEFING = B
            .comment("Allow jutsu and explosive tags to place fire, break plants/blocks and raise earth walls over grass.",
                     "The mobGriefing gamerule must also be true.")
            .define("jutsuGriefing", true);
    public static final ForgeConfigSpec.DoubleValue DAMAGE_MULTIPLIER = B
            .comment("Multiplier applied to all jutsu damage.").defineInRange("damageMultiplier", 1.0, 0.0, 10.0);
    public static final ForgeConfigSpec.DoubleValue COOLDOWN_MULTIPLIER = B
            .comment("Multiplier applied to all jutsu cooldowns.").defineInRange("cooldownMultiplier", 1.0, 0.0, 10.0);
    static { B.pop(); }

    // ---------------------------------------------------------------- chakra
    static { B.push("chakra"); }
    public static final ForgeConfigSpec.DoubleValue CHAKRA_REGEN_MULTIPLIER = B
            .comment("Multiplier applied to natural chakra regeneration and charging.").defineInRange("regenMultiplier", 1.0, 0.0, 10.0);
    public static final ForgeConfigSpec.DoubleValue BASE_CHAKRA_REGEN = B
            .comment("Chakra regenerated per second before bonuses (Uzumaki get 1.5x).").defineInRange("baseRegenPerSecond", 2.0, 0.0, 100.0);
    public static final ForgeConfigSpec.DoubleValue JUTSU_COST_PERCENT = B
            .comment("Every jutsu costs this share of the caster's max chakra (0.15 = 15%: 15 chakra out of 100).")
            .defineInRange("jutsuCostPercent", 0.15, 0.0, 1.0);
    public static final ForgeConfigSpec.IntValue CHAKRA_PER_NINJUTSU = B
            .comment("Max chakra gained per Ninjutsu stat point.").defineInRange("chakraPerNinjutsuPoint", 5, 0, 1000);
    public static final ForgeConfigSpec.DoubleValue NINJUTSU_REGEN_PER_POINT = B
            .comment("Extra chakra regenerated per second per Ninjutsu point (0 to disable).").defineInRange("ninjutsuRegenPerPoint", 0.02, 0.0, 10.0);
    static { B.pop(); }

    // ---------------------------------------------------------------- leveling
    static { B.push("leveling"); }
    public static final ForgeConfigSpec.IntValue XP_BASE = B
            .comment("XP needed to go from level 1 to 2.").defineInRange("xpBase", 100, 1, 1000000);
    public static final ForgeConfigSpec.IntValue XP_PER_LEVEL = B
            .comment("Extra XP needed for each level after that (level N needs xpBase + (N-1) * xpPerLevel).")
            .defineInRange("xpPerLevel", 50, 0, 1000000);
    public static final ForgeConfigSpec.IntValue STAT_POINTS_PER_LEVEL = B.defineInRange("statPointsPerLevel", 4, 0, 100);
    public static final ForgeConfigSpec.IntValue RYO_PER_LEVEL_UP = B.defineInRange("ryoPerLevelUp", 250, 0, 1000000);
    public static final ForgeConfigSpec.IntValue EXP_BOTTLE_XP = B.defineInRange("expBottleXp", 100, 0, 1000000);
    public static final ForgeConfigSpec.IntValue MOB_KILL_XP = B
            .comment("Ninja XP for killing a hostile mob (XP boosts multiply it).").defineInRange("mobKillXp", 5, 0, 1000000);
    public static final ForgeConfigSpec.BooleanValue MOB_XP_ALL_MOBS = B
            .comment("If true, every mob gives mobKillXp (animals too), not just hostile ones.").define("mobXpFromAllMobs", false);
    static { B.pop(); }

    // ---------------------------------------------------------------- jutsu ranks
    static { B.push("jutsuRanks"); }
    public static final ForgeConfigSpec.BooleanValue RANK_REQUIREMENTS = B
            .comment("If true, jutsu scrolls need a minimum player level to learn, depending on the jutsu's rank (D to S).",
                     "With the default rank level caps (Genin 75, Chunin 150), A-rank needs a Chunin and S-rank a Jonin.")
            .define("rankRequirements", true);
    public static final ForgeConfigSpec.IntValue RANK_D_LEVEL = B.defineInRange("minLevelD", 1, 1, 100000);
    public static final ForgeConfigSpec.IntValue RANK_C_LEVEL = B.defineInRange("minLevelC", 15, 1, 100000);
    public static final ForgeConfigSpec.IntValue RANK_B_LEVEL = B.defineInRange("minLevelB", 40, 1, 100000);
    public static final ForgeConfigSpec.IntValue RANK_A_LEVEL = B.defineInRange("minLevelA", 90, 1, 100000);
    public static final ForgeConfigSpec.IntValue RANK_S_LEVEL = B.defineInRange("minLevelS", 175, 1, 100000);
    static { B.pop(); }

    // ---------------------------------------------------------------- ranks
    static { B.push("ranks"); B.comment("Highest level each rank can reach. A Kage (or /shinobi rank) promotes players."); }
    public static final ForgeConfigSpec.IntValue GENIN_LEVEL_CAP = B.defineInRange("geninLevelCap", 75, 1, 100000);
    public static final ForgeConfigSpec.IntValue CHUNIN_LEVEL_CAP = B.defineInRange("chuninLevelCap", 150, 1, 100000);
    public static final ForgeConfigSpec.IntValue JONIN_LEVEL_CAP = B.defineInRange("joninLevelCap", 250, 1, 100000);
    public static final ForgeConfigSpec.IntValue ANBU_LEVEL_CAP = B.defineInRange("anbuLevelCap", 400, 1, 100000);
    public static final ForgeConfigSpec.IntValue SANNIN_LEVEL_CAP = B.defineInRange("sanninLevelCap", 500, 1, 100000);
    static { B.pop(); }

    // ---------------------------------------------------------------- stats
    static { B.push("stats"); }
    public static final ForgeConfigSpec.IntValue SPEED_CAP = B
            .comment("Speed is the only stat with a cap.").defineInRange("speedCap", 50, 1, 10000);
    public static final ForgeConfigSpec.DoubleValue HEALTH_PER_MEDICAL = B
            .comment("Max health per Medical point (2 = one heart).").defineInRange("healthPerMedicalPoint", 1.0, 0.0, 100.0);
    public static final ForgeConfigSpec.DoubleValue SPEED_PER_POINT = B
            .comment("Movement speed bonus per Speed point (0.01 = +1%).").defineInRange("speedPerPoint", 0.01, 0.0, 1.0);
    public static final ForgeConfigSpec.DoubleValue TAIJUTSU_PER_POINT = B
            .comment("Extra fist damage per Taijutsu point.").defineInRange("taijutsuDamagePerPoint", 0.5, 0.0, 100.0);
    public static final ForgeConfigSpec.DoubleValue KENJUTSU_PER_POINT = B
            .comment("Extra sword damage per Kenjutsu point.").defineInRange("kenjutsuDamagePerPoint", 0.4, 0.0, 100.0);
    public static final ForgeConfigSpec.DoubleValue GENJUTSU_PER_POINT = B
            .comment("Genjutsu bonus per point: longer illusions/binds, stronger Amaterasu, better Sharingan dodge (0.02 = +2%).")
            .defineInRange("genjutsuBonusPerPoint", 0.02, 0.0, 1.0);
    public static final ForgeConfigSpec.IntValue SENJUTSU_PER_POINT = B
            .comment("Max Senjutsu (natural energy) per Senjutsu point.").defineInRange("senjutsuPerPoint", 10, 0, 1000);
    public static final ForgeConfigSpec.IntValue RESET_COST_BASE = B
            .comment("Ryo cost to reset stats = base + perLevel * level.").defineInRange("statResetCostBase", 500, 0, 100000000);
    public static final ForgeConfigSpec.IntValue RESET_COST_PER_LEVEL = B.defineInRange("statResetCostPerLevel", 100, 0, 100000000);
    static { B.pop(); }

    // ---------------------------------------------------------------- senjutsu
    static { B.push("senjutsu"); }
    public static final ForgeConfigSpec.DoubleValue SENJUTSU_GATHER_RATE = B
            .comment("Natural energy gathered per second while charging chakra and standing still.").defineInRange("gatherPerSecond", 4.0, 0.0, 1000.0);
    public static final ForgeConfigSpec.DoubleValue SAGE_MODE_DRAIN = B
            .comment("Senjutsu drained per second in Sage Mode.").defineInRange("sageModeDrainPerSecond", 2.0, 0.0, 1000.0);
    public static final ForgeConfigSpec.IntValue SAGE_MODE_MIN = B
            .comment("Senjutsu needed to enter Sage Mode.").defineInRange("sageModeMinimum", 20, 0, 100000);
    public static final ForgeConfigSpec.DoubleValue SAGE_MODE_JUTSU_BONUS = B
            .comment("Extra jutsu damage in Sage Mode (0.25 = +25%).").defineInRange("sageModeJutsuBonus", 0.25, 0.0, 10.0);
    static { B.pop(); }

    // ---------------------------------------------------------------- movement
    static { B.push("ninjaJump"); }
    public static final ForgeConfigSpec.IntValue NINJA_JUMP_COST = B.defineInRange("chakraCost", 15, 0, 100000);
    public static final ForgeConfigSpec.DoubleValue NINJA_JUMP_POWER = B
            .comment("Multiplier for how far the jump launches you.").defineInRange("power", 1.0, 0.1, 5.0);
    static { B.pop(); }

    // ---------------------------------------------------------------- pvp
    static { B.push("pvp"); }
    public static final ForgeConfigSpec.BooleanValue PVP_REWARDS = B
            .comment("Give XP and Ryo for fighting and defeating other players.").define("enabled", true);
    public static final ForgeConfigSpec.IntValue PVP_KILL_XP_BASE = B.defineInRange("killXpBase", 50, 0, 1000000);
    public static final ForgeConfigSpec.IntValue PVP_KILL_XP_PER_LEVEL = B
            .comment("Extra kill XP per level of the defeated player.").defineInRange("killXpPerVictimLevel", 10, 0, 1000000);
    public static final ForgeConfigSpec.IntValue PVP_KILL_RYO_BASE = B.defineInRange("killRyoBase", 50, 0, 1000000);
    public static final ForgeConfigSpec.IntValue PVP_KILL_RYO_PER_LEVEL = B.defineInRange("killRyoPerVictimLevel", 5, 0, 1000000);
    public static final ForgeConfigSpec.IntValue PVP_HIT_XP = B
            .comment("XP for each hit landed on another player.").defineInRange("hitXp", 2, 0, 1000000);
    public static final ForgeConfigSpec.IntValue PVP_HIT_XP_PER_MINUTE = B
            .comment("Most XP a player can earn from hits per minute.").defineInRange("hitXpPerMinute", 30, 0, 1000000);
    public static final ForgeConfigSpec.IntValue PVP_MIN_LEVEL_GAP = B
            .comment("Level-gap rule (works both ways): no PvP rewards when the two players' levels differ by more than",
                     "max(minLevelGap, lowerLevel * levelGapPercent). With the defaults, level 1 and level 12+ players",
                     "get nothing from fighting each other; a level 100 player can be rewarded against levels 50-150.")
            .defineInRange("minLevelGap", 10, 0, 100000);
    public static final ForgeConfigSpec.DoubleValue PVP_LEVEL_GAP_PERCENT = B.defineInRange("levelGapPercent", 0.5, 0.0, 100.0);
    public static final ForgeConfigSpec.IntValue PVP_SAME_VICTIM_COOLDOWN = B
            .comment("Minutes before defeating the same player gives rewards again.").defineInRange("sameVictimCooldownMinutes", 10, 0, 100000);
    public static final ForgeConfigSpec.BooleanValue PVP_REQUIRE_ACTIVITY = B
            .comment("Only reward kills of players who were moving or fighting shortly before (stops AFK alt farming).")
            .define("requireVictimActivity", true);
    public static final ForgeConfigSpec.IntValue PVP_ACTIVITY_WINDOW = B.defineInRange("activityWindowSeconds", 30, 1, 3600);
    static { B.pop(); }

    // ---------------------------------------------------------------- weapons
    static { B.push("weapons"); B.comment("Total attack damage of each ninja weapon (what the tooltip shows; Kenjutsu adds on top)."); }
    public static final ForgeConfigSpec.DoubleValue ZABUZA_DAMAGE = B.defineInRange("kubikiribochoDamage", 32.0, 1.0, 10000.0);
    public static final ForgeConfigSpec.DoubleValue SAMEHADA_DAMAGE = B.defineInRange("samehadaDamage", 34.0, 1.0, 10000.0);
    public static final ForgeConfigSpec.DoubleValue HIDAN_SCYTHE_DAMAGE = B.defineInRange("hidanScytheDamage", 24.0, 1.0, 10000.0);
    public static final ForgeConfigSpec.DoubleValue SWORD_OF_FIRE_DAMAGE = B.defineInRange("swordOfFireDamage", 19.0, 1.0, 10000.0);
    public static final ForgeConfigSpec.DoubleValue SHAKUJO_DAMAGE = B.defineInRange("shakujoDamage", 17.0, 1.0, 10000.0);
    public static final ForgeConfigSpec.DoubleValue KUSANAGI_DAMAGE = B.defineInRange("kusanagiDamage", 15.0, 1.0, 10000.0);
    public static final ForgeConfigSpec.DoubleValue KATANA_DAMAGE = B.defineInRange("katanaDamage", 11.0, 1.0, 10000.0);
    public static final ForgeConfigSpec.DoubleValue SAMEHADA_STEAL = B
            .comment("Chakra Samehada steals from a player it hits.").defineInRange("samehadaChakraSteal", 10.0, 0.0, 10000.0);
    public static final ForgeConfigSpec.DoubleValue SAMEHADA_FEED = B
            .comment("Chakra Samehada gives its wielder on every hit, on top of what it steals.").defineInRange("samehadaChakraFeed", 5.0, 0.0, 10000.0);
    public static final ForgeConfigSpec.DoubleValue KUSANAGI_CHAKRA_COST = B
            .comment("Chakra each Kusanagi hit spends on Chidori Flow (paralyses the target).").defineInRange("kusanagiChidoriCost", 4.0, 0.0, 10000.0);
    public static final ForgeConfigSpec.DoubleValue HIDAN_LIFESTEAL = B
            .comment("Part of the damage dealt with Hidan's scythe that heals the wielder (0.2 = 20%).").defineInRange("hidanScytheLifesteal", 0.2, 0.0, 10.0);
    static { B.pop(); }

    // ---------------------------------------------------------------- sharingan
    static { B.push("sharingan"); B.comment("Sharingan evolution: 1 tomoe -> 2 -> 3 -> Mangekyou, one stage at a time."); }
    public static final ForgeConfigSpec.IntValue SHARINGAN_2_LEVEL = B.defineInRange("twoTomoeLevel", 30, 1, 100000);
    public static final ForgeConfigSpec.IntValue SHARINGAN_3_LEVEL = B.defineInRange("threeTomoeLevel", 60, 1, 100000);
    public static final ForgeConfigSpec.IntValue MANGEKYOU_LEVEL = B
            .comment("Level needed (with 3 tomoe) before a near-death experience awakens the Mangekyou.")
            .defineInRange("mangekyouLevel", 100, 1, 100000);
    public static final ForgeConfigSpec.DoubleValue MANGEKYOU_HEALTH = B
            .comment("The near-death experience: surviving at or below this share of max health (0.05 = 5%).")
            .defineInRange("mangekyouNearDeathHealth", 0.05, 0.001, 0.5);
    public static final ForgeConfigSpec.BooleanValue EYE_THEFT = B
            .comment("Defeating a Sharingan user in PvP (when the kill gives rewards) takes one of their eyes as an item.",
                     "Players who weren't born Uchiha lose their Sharingan when it's taken.")
            .define("eyeTheft", true);
    static { B.pop(); }

    // ---------------------------------------------------------------- combat tag
    static { B.push("combat"); }
    public static final ForgeConfigSpec.IntValue COMBAT_TAG_SECONDS = B
            .comment("Seconds a player stays in combat after hitting or being hit by another player (0 = off).")
            .defineInRange("tagSeconds", 60, 0, 3600);
    public static final ForgeConfigSpec.BooleanValue COMBAT_LOG_KILL = B
            .comment("Players who log out while in combat are killed (their opponent gets the kill).").define("killOnLogout", true);
    public static final ForgeConfigSpec.BooleanValue COMBAT_BLOCK_COMMANDS = B
            .comment("Block every command for players in combat.").define("blockCommands", true);
    static { B.pop(); }

    // ---------------------------------------------------------------- teams
    static { B.push("teams"); }
    public static final ForgeConfigSpec.IntValue TEAM_MAX = B.defineInRange("maxMembers", 4, 2, 64);
    static { B.pop(); }

    public static final ForgeConfigSpec SPEC = B.build();

    // ---------------------------------------------------------------- safe readers
    public static boolean b(ForgeConfigSpec.BooleanValue v) {
        try {
            return v.get();
        } catch (RuntimeException e) {
            return v.getDefault();
        }
    }

    public static int i(ForgeConfigSpec.IntValue v) {
        try {
            return v.get();
        } catch (RuntimeException e) {
            return v.getDefault();
        }
    }

    public static double d(ForgeConfigSpec.DoubleValue v) {
        try {
            return v.get();
        } catch (RuntimeException e) {
            return v.getDefault();
        }
    }

    public static float f(ForgeConfigSpec.DoubleValue v) {
        return (float) d(v);
    }

    private Config() {}
}
