package com.shinobiarts.item;

import com.shinobiarts.ninja.PlayerDataManager;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;
import java.util.List;

/** A Ryo coin. Deposit it with a Frog Wallet to add its value to your Ryo. */
public class CoinItem extends Item {
    public enum Coin {
        BRONZE("bronze", 100, 0xC27A3A),
        SILVER("silver", 500, 0xC9D1D9),
        GOLD("gold", 1000, 0xF2C230);

        private final String id;
        private final int value;
        private final int rgb;

        Coin(String id, int value, int rgb) {
            this.id = id;
            this.value = value;
            this.rgb = rgb;
        }

        public String id() {
            return id;
        }

        public int value() {
            return value;
        }

        public int rgb() {
            return rgb;
        }

        @Nullable
        public static Coin byOrdinal(int ordinal) {
            return ordinal >= 0 && ordinal < values().length ? values()[ordinal] : null;
        }
    }

    private final Coin coin;

    public CoinItem(Coin coin, Properties properties) {
        super(properties);
        this.coin = coin;
    }

    public Coin coin() {
        return coin;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.shinobiarts.coin", PlayerDataManager.formatRyo(coin.value())).withStyle(ChatFormatting.GOLD));
        if (stack.getCount() > 1) {
            tooltip.add(Component.translatable("tooltip.shinobiarts.coin_stack",
                    PlayerDataManager.formatRyo((long) coin.value() * stack.getCount())).withStyle(ChatFormatting.GRAY));
        }
        tooltip.add(Component.translatable("tooltip.shinobiarts.coin_hint").withStyle(ChatFormatting.DARK_GRAY));
    }
}
