package com.shinobiarts.item;

import com.shinobiarts.Config;
import com.shinobiarts.ninja.PlayerDataManager;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;
import java.util.List;

/** Right-click to gain ninja XP (100 by default). Shift-right-click uses the whole stack. */
public class ExpBottleItem extends Item {
    public ExpBottleItem(Properties properties) {
        super(properties);
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (player instanceof ServerPlayer sp) {
            int count = player.isShiftKeyDown() ? stack.getCount() : 1;
            long xp = (long) count * Config.i(Config.EXP_BOTTLE_XP);
            if (!player.getAbilities().instabuild) stack.shrink(count);
            sp.displayClientMessage(Component.translatable("message.shinobiarts.xp_gained", xp).withStyle(ChatFormatting.GREEN), true);
            level.playSound(null, sp.getX(), sp.getY(), sp.getZ(), SoundEvents.EXPERIENCE_ORB_PICKUP, SoundSource.PLAYERS, 0.8f, 0.9f);
            PlayerDataManager.addXp(sp, xp);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.shinobiarts.exp_bottle", Config.i(Config.EXP_BOTTLE_XP)).withStyle(ChatFormatting.GREEN));
    }
}
