package com.shinobiarts.jutsu;

import com.shinobiarts.Config;
import com.shinobiarts.item.ReleaseItem;
import com.shinobiarts.network.ModNetwork;
import com.shinobiarts.ninja.ChakraNature;
import com.shinobiarts.ninja.Clan;
import com.shinobiarts.ninja.Dojutsu;
import com.shinobiarts.ninja.SharinganManager;
import com.shinobiarts.ninja.NinjaData;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;

import javax.annotation.Nullable;

/** Validates and performs a cast of the selected jutsu in the release the player is holding. */
public final class JutsuCaster {
    private JutsuCaster() {}

    public static void tryCast(ServerPlayer player) {
        tryCast(player, ReleaseItem.heldRelease(player), InteractionHand.MAIN_HAND);
    }

    /** Casts the selected jutsu of a release (right-clicking with a release in that hand). */
    public static void tryCast(ServerPlayer player, @Nullable ChakraNature release, InteractionHand hand) {
        NinjaData data = NinjaData.get(player);
        if (data == null || player.isSpectator() || !player.isAlive()) return;

        if (release == null) {
            player.displayClientMessage(Component.translatable("message.shinobiarts.hold_release").withStyle(ChatFormatting.GRAY), true);
            return;
        }
        if (!data.hasNature(release)) {
            player.displayClientMessage(Component.translatable("message.shinobiarts.release_locked", release.displayName()).withStyle(ChatFormatting.RED), true);
            return;
        }
        Jutsu jutsu = data.selectedJutsu(release);
        if (jutsu == null) {
            player.displayClientMessage(Component.translatable("message.shinobiarts.release_empty", release.displayName()).withStyle(ChatFormatting.GRAY), true);
            return;
        }

        long now = player.level().getGameTime();
        long remaining = data.cooldownRemaining(jutsu.id(), now);
        if (remaining > 0) {
            player.displayClientMessage(Component.translatable("message.shinobiarts.cooldown", jutsu.displayName(),
                    String.format("%.1f", remaining / 20.0f)).withStyle(ChatFormatting.GRAY), true);
            return;
        }

        if (jutsu.needsDojutsu() && !(data.isSharinganActive() && data.getSharinganStage() == Dojutsu.MANGEKYOU)) {
            player.displayClientMessage(Component.translatable("message.shinobiarts.needs_mangekyou").withStyle(ChatFormatting.RED), true);
            return;
        }

        boolean creative = player.getAbilities().instabuild;
        float cost = jutsu.cost(data);
        if (!creative && data.getChakra() < cost) {
            player.displayClientMessage(Component.translatable("message.shinobiarts.not_enough_chakra",
                    (int) data.getChakra(), (int) Math.ceil(cost)).withStyle(ChatFormatting.RED), true);
            player.playNotifySound(SoundEvents.FIRE_EXTINGUISH, SoundSource.PLAYERS, 0.4f, 1.8f);
            return;
        }

        if (!jutsu.action().perform(player, data)) return;

        if (!creative) data.consumeChakra(cost);
        long cooldown = Math.max(1L, Math.round(jutsu.cooldown() * Config.d(Config.COOLDOWN_MULTIPLIER)));
        data.setCooldown(jutsu.id(), now + cooldown);
        player.swing(hand, true);
        player.displayClientMessage(jutsu.displayName(), true);
        ModNetwork.sync(player);

        sharinganCopy(player, jutsu);
        com.shinobiarts.entity.ShadowClone.copyOwnerJutsu(player, jutsu.id()); // clones copy hand jutsu
    }

    /** Uchiha with an active Sharingan who watch someone cast a jutsu learn it instantly. */
    private static void sharinganCopy(ServerPlayer caster, Jutsu jutsu) {
        if (jutsu.clan() != null || jutsu.needsDojutsu()) return;
        for (ServerPlayer watcher : caster.serverLevel().players()) {
            if (watcher == caster) continue;
            NinjaData data = NinjaData.get(watcher);
            if (data == null || !data.isSharinganActive() || data.knows(jutsu.id())) continue;
            double range = SharinganManager.copyRange(data);
            if (watcher.distanceToSqr(caster) > range * range || !watcher.hasLineOfSight(caster)) continue;
            data.learn(jutsu.id());
            watcher.sendSystemMessage(Component.translatable("message.shinobiarts.sharingan_copy", jutsu.displayName())
                    .withStyle(ChatFormatting.DARK_RED));
            watcher.playNotifySound(SoundEvents.ENCHANTMENT_TABLE_USE, SoundSource.PLAYERS, 1.0f, 0.8f);
            ModNetwork.sync(watcher);
        }
    }
}
