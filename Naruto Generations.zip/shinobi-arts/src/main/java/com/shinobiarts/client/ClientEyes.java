package com.shinobiarts.client;

import com.shinobiarts.entity.ShadowClone;
import com.shinobiarts.ninja.SharinganManager;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;

import java.util.HashMap;
import java.util.Map;

/** Which Sharingan stage each visible player's face shows (sent by the server). Clones carry their own. */
public final class ClientEyes {
    private static final Map<Integer, Integer> STAGES = new HashMap<>();

    private ClientEyes() {}

    public static void set(int entityId, int stage) {
        if (stage <= 0) STAGES.remove(entityId);
        else STAGES.put(entityId, stage);
    }

    /** Sharingan stage drawn on this entity's face, or 0. */
    public static int stage(Entity entity) {
        if (entity instanceof ShadowClone clone) return clone.getEyesStage();
        Minecraft mc = Minecraft.getInstance();
        if (entity == mc.player) return SharinganManager.visibleStage(ClientNinjaData.get());
        return STAGES.getOrDefault(entity.getId(), 0);
    }

    public static void clear() {
        STAGES.clear();
    }
}
