package com.shinobiarts.client;

import com.shinobiarts.ShinobiArts;
import com.shinobiarts.network.ActionPacket;
import com.shinobiarts.network.ModNetwork;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.HoverEvent;
import net.minecraft.network.chat.Style;
import net.minecraft.client.player.LocalPlayer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.gui.overlay.ForgeGui;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = ShinobiArts.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class ClientEvents {
    private static boolean charging;
    private static boolean jumpWasDown;
    /** Ticks until the Discord invite is shown after joining a world or server (-1 = nothing to show). */
    private static int discordDelay = -1;

    public static final String DISCORD_URL = "https://discord.gg/EGVB4Sjzu3";

    private ClientEvents() {}

    /** Ninja Jump is checked before the player moves this tick, while they're still on the ground. */
    @SubscribeEvent
    public static void onClientTickStart(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.START) return;
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null || mc.screen != null) {
            jumpWasDown = false;
            return;
        }
        boolean jumpDown = mc.options.keyJump.isDown();
        if (jumpDown && !jumpWasDown && mc.options.keyShift.isDown() && player.onGround()
                && !player.getAbilities().flying && !player.isPassenger()) {
            ModNetwork.toServer(new ActionPacket(ActionPacket.NINJA_JUMP));
        }
        jumpWasDown = jumpDown;
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.getConnection() == null) {
            charging = false;
            return;
        }
        if (discordDelay > 0 && --discordDelay == 0) {
            discordDelay = -1;
            mc.player.sendSystemMessage(discordInvite());
        }

        while (KeyBinds.NEXT.consumeClick()) ModNetwork.toServer(new ActionPacket(ActionPacket.NEXT));
        while (KeyBinds.PREV.consumeClick()) ModNetwork.toServer(new ActionPacket(ActionPacket.PREV));
        while (KeyBinds.DOJUTSU.consumeClick()) ModNetwork.toServer(new ActionPacket(ActionPacket.DOJUTSU));
        while (KeyBinds.SAGE.consumeClick()) ModNetwork.toServer(new ActionPacket(ActionPacket.SAGE_MODE));
        while (KeyBinds.STATS.consumeClick()) {
            if (mc.screen == null) ClientHooks.openStats();
        }

        // Charging is held: tell the server when it starts and stops.
        boolean wantCharge = KeyBinds.CHARGE.isDown() && mc.screen == null;
        if (wantCharge != charging) {
            charging = wantCharge;
            ModNetwork.toServer(new ActionPacket(wantCharge ? ActionPacket.CHARGE_START : ActionPacket.CHARGE_STOP));
        }
    }

    /** Replaces the vanilla hearts with a numeric health bar in the same spot above the hotbar. */
    @SubscribeEvent
    public static void onRenderOverlay(RenderGuiOverlayEvent.Pre event) {
        if (!event.getOverlay().id().equals(VanillaGuiOverlay.PLAYER_HEALTH.id()) || !ClientNinjaData.get().isInitialized()) return;
        event.setCanceled(true);
        Minecraft mc = Minecraft.getInstance();
        if (!(mc.gui instanceof ForgeGui gui) || mc.player == null || mc.options.hideGui || !gui.shouldDrawSurvivalElements()) return;
        int width = event.getWindow().getGuiScaledWidth();
        int height = event.getWindow().getGuiScaledHeight();
        ShinobiHud.drawHealthBar(event.getGuiGraphics(), width / 2 - 91, height - gui.leftHeight, mc.player);
        gui.leftHeight += 10; // keep the armor bar above it, like vanilla hearts do
    }

    /** Every time you join a world or server, the Discord invite appears in chat (after the join messages). */
    @SubscribeEvent
    public static void onLoggingIn(ClientPlayerNetworkEvent.LoggingIn event) {
        discordDelay = 40;
    }

    /** The whole line is clickable and opens the Discord invite. */
    public static Component discordInvite() {
        Style link = Style.EMPTY
                .withClickEvent(new ClickEvent(ClickEvent.Action.OPEN_URL, DISCORD_URL))
                .withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, Component.literal("Click to join the Discord")));
        return Component.literal("Join the discord here for insights on new updates and sneak peeks! ")
                .withStyle(link.withColor(ChatFormatting.GOLD))
                .append(Component.literal(DISCORD_URL).withStyle(link.withColor(ChatFormatting.AQUA).withUnderlined(true)));
    }

    @SubscribeEvent
    public static void onLoggingOut(ClientPlayerNetworkEvent.LoggingOut event) {
        discordDelay = -1;
        ClientEyes.clear();
        charging = false;
        ClientNinjaData.reset();
        ShinobiHud.reset();
    }
}
