package com.shinobiarts.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.shinobiarts.Config;
import com.shinobiarts.item.CoinItem;
import com.shinobiarts.item.ReleaseItem;
import com.shinobiarts.jutsu.Jutsu;
import com.shinobiarts.ninja.ChakraNature;
import com.shinobiarts.ninja.Clan;
import com.shinobiarts.ninja.NinjaData;
import com.shinobiarts.ninja.PlayerDataManager;
import com.shinobiarts.registry.ModItems;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.client.gui.overlay.IGuiOverlay;

import java.util.ArrayList;
import java.util.List;

/**
 * The main HUD, drawn just left of the hotbar (leaving room for the off-hand slot):
 * health as numbers, Ryo, the blue chakra bar, the green Senjutsu bar, and the jutsu slots of the
 * release you're holding with a selection arrow and cooldown overlays. Shrinks on narrow screens.
 */
public final class ShinobiHud {
    private static final int W = 132;
    private static final int H = 54;
    private static final int SLOT = 13;
    private static final int SLOT_GAP = 2;
    private static final int MAX_VISIBLE_SLOTS = 7;

    private static final int CHAKRA_COLOR = 0xFF2F8CFF;
    private static final int CHAKRA_CHARGE_COLOR = 0xFF8FE8FF;
    private static final int SENJUTSU_COLOR = 0xFF3FBF4A;
    private static final int SAGE_COLOR = 0xFFF0A02A;

    /** The chakra figure drawn left of the chakra and Senjutsu bars (111 x 128 texture). */
    private static final ResourceLocation FIGURE = new ResourceLocation(com.shinobiarts.ShinobiArts.MODID, "textures/gui/chakra_figure.png");
    private static final int FIGURE_W = 15, FIGURE_H = 17;
    private static final int BAR_X = 4 + FIGURE_W;

    public static final IGuiOverlay OVERLAY = (gui, g, partialTick, width, height) -> render(g, width, height);

    // Smoothly animated bar values.
    private static float shownChakra = -1;
    private static float shownSenjutsu = -1;
    private static long lastFrame;

    private ShinobiHud() {}

    public static void reset() {
        shownChakra = -1;
        shownSenjutsu = -1;
    }

    private static void render(GuiGraphics g, int width, int height) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (mc.options.hideGui || player == null || mc.level == null || player.isSpectator()) return;
        NinjaData d = ClientNinjaData.get();
        if (!d.isInitialized()) return;
        long now = mc.level.getGameTime();

        drawTints(g, d, width, height);
        animate(d);

        // Sit to the left of the hotbar and the off-hand slot.
        int right = width / 2 - 91 - 32;
        float scale = Mth.clamp((right - 4) / (float) W, 0.55f, 1.0f);
        float left = right - W * scale;
        float top = height - 3 - H * scale;

        g.pose().pushPose();
        g.pose().translate(left, top, 0);
        g.pose().scale(scale, scale, 1f);
        drawPanel(g, mc.font, player, d, now);
        g.pose().popPose();
    }

    private static void animate(NinjaData d) {
        long t = System.nanoTime();
        float dt = lastFrame == 0 ? 1f : Math.min(1f, (t - lastFrame) / 1.0e9f * 10f);
        lastFrame = t;
        if (shownChakra < 0) shownChakra = d.getChakra();
        if (shownSenjutsu < 0) shownSenjutsu = d.getSenjutsu();
        shownChakra += (d.getChakra() - shownChakra) * dt;
        shownSenjutsu += (d.getSenjutsu() - shownSenjutsu) * dt;
    }

    private static void drawTints(GuiGraphics g, NinjaData d, int width, int height) {
        int band = Math.max(20, height / 7);
        if (d.isDojutsuActive()) {
            int tint = d.getActiveDojutsu() == com.shinobiarts.ninja.Dojutsu.SHARINGAN ? 0x50A00000 : 0x40C8DCFF;
            g.fillGradient(0, 0, width, band, tint, 0x00000000);
            g.fillGradient(0, height - band, width, height, 0x00000000, tint);
        } else if (d.isSageMode()) {
            g.fillGradient(0, 0, width, band, 0x30F0A02A, 0x00000000);
            g.fillGradient(0, height - band, width, height, 0x00000000, 0x30F0A02A);
        }
    }

    private static void drawPanel(GuiGraphics g, Font font, LocalPlayer player, NinjaData d, long now) {
        ChakraNature release = ReleaseItem.heldRelease(player);
        int accent = release != null ? 0xFF000000 | release.rgb() : 0xFF3A3A48;

        // Status tags above the panel.
        List<Component> tags = new ArrayList<>();
        if (d.isDojutsuActive()) tags.add(d.dojutsuName(d.getActiveDojutsu()));
        if (d.isSageMode()) tags.add(Component.translatable("hud.shinobiarts.sage"));
        if (d.isCharging()) tags.add(Component.translatable("hud.shinobiarts.charging"));
        if (d.getRasenganUntil() > now) tags.add(Component.translatable("hud.shinobiarts.rasengan"));
        if (d.getSubstitutionUntil() > now) tags.add(Component.translatable("hud.shinobiarts.substitution"));
        if (d.getBoostTicks() > 0) {
            long left = d.getBoostTicks() - Math.max(0, now - ClientNinjaData.syncTime());
            if (left > 0) {
                long secs = left / 20;
                tags.add(Component.translatable("hud.shinobiarts.boost", com.shinobiarts.item.XpBoostItem.format(d.getBoostMultiplier()),
                        String.format("%d:%02d", secs / 60, secs % 60)).withStyle(net.minecraft.ChatFormatting.LIGHT_PURPLE));
            }
        }
        if (!tags.isEmpty()) {
            Component line = Component.empty();
            for (int i = 0; i < tags.size(); i++) {
                if (i > 0) ((net.minecraft.network.chat.MutableComponent) line).append(Component.literal("  "));
                ((net.minecraft.network.chat.MutableComponent) line).append(tags.get(i));
            }
            smallText(g, font, line, 2, -8, 0.75f, 0xFFFFFF);
        }

        // Panel background with an accent line in the held release's colour.
        g.fill(0, 0, W, H, 0x9010101A);
        g.fill(0, 0, W, 1, accent);
        g.fill(0, H - 1, W, H, 0x60000000);

        // Row 1: Ryo on the left, rank and level on the right.
        drawCoin(g, 2, 2);
        g.drawString(font, PlayerDataManager.formatRyo(d.getRyo()), 12, 3, 0xFFF2C230, true);
        Component lvl = Component.literal("Lv " + d.getLevel()).withStyle(d.getRank().color());
        g.drawString(font, lvl, W - 3 - font.width(lvl), 3, 0xFFFFFFFF, true);

        // Rows 2-3: the chakra figure, then the chakra bar and the Senjutsu bar (once you've invested in Senjutsu).
        RenderSystem.enableBlend();
        g.blit(FIGURE, 2, 12, FIGURE_W, FIGURE_H, 0, 0, 111, 128, 111, 128);
        drawBar(g, font, BAR_X, 14, W - BAR_X - 3, 7, shownChakra, d.getChakra(), d.maxChakra(),
                d.isCharging() ? CHAKRA_CHARGE_COLOR : CHAKRA_COLOR, now, d.isCharging());
        if (d.maxSenjutsu() > 0) {
            drawBar(g, font, BAR_X, 23, W - BAR_X - 3, 5, shownSenjutsu, d.getSenjutsu(), d.maxSenjutsu(),
                    d.isSageMode() ? SAGE_COLOR : SENJUTSU_COLOR, now, false);
        }

        // Rows 4-5: release icon, jutsu slots, selected jutsu.
        int slotY = 33;
        if (release == null) {
            smallText(g, font, Component.translatable("hud.shinobiarts.hold_release"), 4, slotY + 4, 0.75f, 0xFF9A9AAA);
            return;
        }
        RenderSystem.enableBlend();
        g.blit(release.icon(), 2, slotY - 1, 15, 15, 0, 0, 64, 64, 64, 64);
        List<Jutsu> slots = d.slots(release);
        if (!d.hasNature(release)) {
            smallText(g, font, Component.translatable("hud.shinobiarts.release_locked"), 20, slotY + 4, 0.75f, 0xFFFF6B6B);
            return;
        }
        if (slots.isEmpty()) {
            smallText(g, font, Component.translatable("hud.shinobiarts.release_empty"), 20, slotY + 4, 0.75f, 0xFF9A9AAA);
            return;
        }
        int selected = d.getSelectedSlot(release);
        int first = Mth.clamp(selected - MAX_VISIBLE_SLOTS / 2, 0, Math.max(0, slots.size() - MAX_VISIBLE_SLOTS));
        int last = Math.min(slots.size(), first + MAX_VISIBLE_SLOTS);
        for (int i = first; i < last; i++) {
            int x = 20 + (i - first) * (SLOT + SLOT_GAP);
            drawSlot(g, font, slots.get(i), x, slotY, i == selected, release, d, now);
        }
        if (first > 0) smallText(g, font, Component.literal("<"), 17, slotY + 3, 0.7f, 0xFFFFFFFF);
        if (last < slots.size()) smallText(g, font, Component.literal(">"), W - 4, slotY + 3, 0.7f, 0xFFFFFFFF);

        Jutsu jutsu = slots.get(selected);
        long remaining = d.cooldownRemaining(jutsu.id(), now);
        Component status = remaining > 0
                ? Component.literal(String.format("  %.1fs", remaining / 20.0f)).withStyle(net.minecraft.ChatFormatting.GRAY)
                : (d.getChakra() >= jutsu.cost(d)
                    ? Component.translatable("hud.shinobiarts.ready").withStyle(net.minecraft.ChatFormatting.GREEN)
                    : Component.translatable("hud.shinobiarts.low_chakra").withStyle(net.minecraft.ChatFormatting.RED));
        Component name = Component.literal(shortName(jutsu)).withStyle(jutsu.displayName().getStyle())
                .append(Component.literal(" (" + (int) Math.ceil(jutsu.cost(d)) + ")").withStyle(net.minecraft.ChatFormatting.AQUA))
                .append(status);
        smallText(g, font, name, 3, slotY + SLOT + 4, 0.75f, 0xFFFFFFFF);
    }

    private static void drawSlot(GuiGraphics g, Font font, Jutsu jutsu, int x, int y, boolean selected,
                                 ChakraNature release, NinjaData d, long now) {
        int color = jutsu.clan() != null ? 0xFF7A1F2B : 0xFF000000 | release.rgb();
        g.fill(x, y, x + SLOT, y + SLOT, 0xFF15151C);
        g.fill(x + 1, y + 1, x + SLOT - 1, y + SLOT - 1, (color & 0x00FFFFFF) | 0xA0000000);
        // two-letter abbreviation
        String abbr = abbreviation(jutsu);
        float s = 0.7f;
        g.pose().pushPose();
        g.pose().translate(x + SLOT / 2f - font.width(abbr) * s / 2f, y + SLOT / 2f - 3f, 0);
        g.pose().scale(s, s, 1f);
        g.drawString(font, abbr, 0, 0, 0xFFFFFFFF, true);
        g.pose().popPose();

        // cooldown overlay: darkens from the top, shrinking as it recharges
        long remaining = d.cooldownRemaining(jutsu.id(), now);
        if (remaining > 0) {
            long total = Math.max(1L, Math.round(jutsu.cooldown() * Config.d(Config.COOLDOWN_MULTIPLIER)));
            int h = Mth.clamp((int) Math.ceil(SLOT * (remaining / (float) total)), 1, SLOT);
            g.fill(x, y, x + SLOT, y + h, 0xB0000000);
            String secs = remaining >= 200 ? String.valueOf(remaining / 20) : String.format("%.0f", Math.ceil(remaining / 20.0));
            g.pose().pushPose();
            g.pose().translate(x + SLOT / 2f - font.width(secs) * 0.6f / 2f, y + SLOT / 2f - 2.5f, 0);
            g.pose().scale(0.6f, 0.6f, 1f);
            g.drawString(font, secs, 0, 0, 0xFFFFD34A, true);
            g.pose().popPose();
        }

        if (selected) {
            // white frame + arrow above
            g.fill(x - 1, y - 1, x + SLOT + 1, y, 0xFFFFFFFF);
            g.fill(x - 1, y + SLOT, x + SLOT + 1, y + SLOT + 1, 0xFFFFFFFF);
            g.fill(x - 1, y, x, y + SLOT, 0xFFFFFFFF);
            g.fill(x + SLOT, y, x + SLOT + 1, y + SLOT, 0xFFFFFFFF);
            int cx = x + SLOT / 2;
            g.fill(cx - 2, y - 4, cx + 3, y - 3, 0xFFFFFFFF);
            g.fill(cx - 1, y - 3, cx + 2, y - 2, 0xFFFFFFFF);
        }
    }

    /**
     * A soft, rounded bar: a faint glow in the bar's color, a dark see-through track, and a fill with rounded ends
     * that is lighter at the top and fades darker toward the bottom. Drawn at double resolution so the rounded
     * ends stay smooth.
     */
    private static void drawBar(GuiGraphics g, Font font, int x, int y, int w, int h, float shown, float actual, float max,
                                int color, long now, boolean shimmer) {
        float frac = max <= 0 ? 0 : Mth.clamp(shown / max, 0f, 1f);
        g.pose().pushPose();
        g.pose().translate(x, y, 0);
        g.pose().scale(0.5f, 0.5f, 1f);
        int bw = w * 2, bh = h * 2;

        // glow: a slightly larger pill in the bar's color, very transparent
        pill(g, -2, -2, bw + 4, bh + 4, (color & 0x00FFFFFF) | 0x26000000, 0, 0);
        pill(g, -1, -1, bw + 2, bh + 2, 0x80080810, 0, 0);
        // track
        pill(g, 0, 0, bw, bh, 0xB01A1A26, 0, 0);
        // fill
        int filled = Math.round(bw * frac);
        if (filled > 0) {
            int top = shade(color, 1.35f), bottom = shade(color, 0.62f);
            pill(g, 0, 0, filled, bh, color, top, bottom);
            // soft highlight across the upper third
            pill(g, 2, 1, filled - 4, Math.max(2, bh / 3), 0x30FFFFFF, 0, 0);
            if (shimmer) {
                int pos = (int) ((now * 8) % (bw + 24)) - 12;
                int s0 = Mth.clamp(pos, 0, filled), s1 = Mth.clamp(pos + 12, 0, filled);
                if (s1 > s0) g.fill(s0, 1, s1, bh - 1, 0x50FFFFFF);
            }
        }
        g.pose().popPose();

        if (h >= 6) {
            String text = (int) actual + "/" + (int) max;
            float s = 0.65f;
            g.pose().pushPose();
            g.pose().translate(x + w / 2f - font.width(text) * s / 2f, y + (h - 9 * s) / 2f + 0.5f, 0);
            g.pose().scale(s, s, 1f);
            g.drawString(font, text, 0, 0, 0xFFFFFFFF, true);
            g.pose().popPose();
        }
    }

    /**
     * A horizontal pill (rectangle with fully rounded ends), drawn one row at a time.
     * If top/bottom are non-zero the rows blend from the top color through `color` to the bottom color.
     */
    private static void pill(GuiGraphics g, int x, int y, int w, int h, int color, int top, int bottom) {
        if (w <= 0 || h <= 0) return;
        float r = Math.min(h, w) / 2f;
        for (int row = 0; row < h; row++) {
            float dy = row + 0.5f - h / 2f;
            float half = (float) Math.sqrt(Math.max(0f, r * r - dy * dy));
            int inset = Math.round(r - half);
            if (inset * 2 >= w) continue;
            int c = color;
            if (top != 0) {
                float t = h <= 1 ? 0f : row / (float) (h - 1);
                c = t < 0.5f ? lerpColor(top, color, t * 2f) : lerpColor(color, bottom, (t - 0.5f) * 2f);
            }
            g.fill(x + inset, y + row, x + w - inset, y + row + 1, c);
        }
    }

    private static int shade(int argb, float f) {
        int r = Math.min(255, Math.round(((argb >> 16) & 0xFF) * f));
        int gr = Math.min(255, Math.round(((argb >> 8) & 0xFF) * f));
        int b = Math.min(255, Math.round((argb & 0xFF) * f));
        return (argb & 0xFF000000) | (r << 16) | (gr << 8) | b;
    }

    private static int lerpColor(int a, int b, float t) {
        int out = 0;
        for (int shift = 0; shift <= 24; shift += 8) {
            int ca = (a >> shift) & 0xFF, cb = (b >> shift) & 0xFF;
            out |= Math.round(ca + (cb - ca) * t) << shift;
        }
        return out;
    }

    /**
     * The health bar that replaces the vanilla hearts, drawn where the hearts were (above the hotbar).
     * Shows current/max health as numbers, with absorption as a gold extension.
     */
    public static void drawHealthBar(GuiGraphics g, int x, int y, LocalPlayer player) {
        Font font = Minecraft.getInstance().font;
        int w = 81, h = 9;
        float max = Math.max(1f, player.getMaxHealth());
        float hp = Mth.clamp(player.getHealth(), 0f, max);
        float abs = player.getAbsorptionAmount();
        g.fill(x - 1, y - 1, x + w + 1, y + h + 1, 0xFF0B0B12);
        g.fill(x, y, x + w, y + h, 0xFF2A1416);
        int filled = Math.round(w * hp / max);
        boolean low = hp / max <= 0.25f;
        int color = low && (System.currentTimeMillis() / 300) % 2 == 0 ? 0xFFFF5A5A : 0xFFD8323A;
        g.fill(x, y, x + filled, y + h, color);
        g.fill(x, y, x + filled, y + 3, 0x40FFFFFF);
        if (abs > 0) {
            int absW = Math.min(w, Math.round(w * abs / max));
            g.fill(x, y + h - 2, x + absW, y + h, 0xFFFFD34A);
        }
        drawHeart(g, x + 2, y + 1);
        String text = (int) Math.ceil(hp) + " / " + (int) Math.ceil(max) + (abs > 0 ? "  +" + (int) Math.ceil(abs) : "");
        g.drawString(font, text, x + (w - font.width(text)) / 2 + 4, y + 1, 0xFFFFFFFF, true);
    }

    /** A tiny pixel heart. */
    private static void drawHeart(GuiGraphics g, int x, int y) {
        int red = 0xFFE03A3A, dark = 0xFF8A1C1C;
        g.fill(x + 1, y, x + 3, y + 1, red);
        g.fill(x + 4, y, x + 6, y + 1, red);
        g.fill(x, y + 1, x + 7, y + 4, red);
        g.fill(x + 1, y + 4, x + 6, y + 5, red);
        g.fill(x + 2, y + 5, x + 5, y + 6, dark);
        g.fill(x + 3, y + 6, x + 4, y + 7, dark);
        g.fill(x + 1, y + 1, x + 2, y + 2, 0xFFFFB0B0);
    }

    /** Draws the gold Ryo coin item at half size. */
    private static void drawCoin(GuiGraphics g, int x, int y) {
        g.pose().pushPose();
        g.pose().translate(x, y, 0);
        g.pose().scale(0.55f, 0.55f, 1f);
        g.renderItem(new ItemStack(ModItems.coin(CoinItem.Coin.GOLD)), 0, 0);
        g.pose().popPose();
    }

    private static void smallText(GuiGraphics g, Font font, Component text, float x, float y, float scale, int color) {
        g.pose().pushPose();
        g.pose().translate(x, y, 0);
        g.pose().scale(scale, scale, 1f);
        g.drawString(font, text, 0, 0, color, true);
        g.pose().popPose();
    }

    /** "Fire Release: Great Fireball" -> "Great Fireball". */
    static String shortName(Jutsu jutsu) {
        String full = jutsu.displayName().getString();
        int colon = full.indexOf(": ");
        return colon >= 0 ? full.substring(colon + 2) : full;
    }

    /** "Great Fireball" -> "GF", "Chidori" -> "Ch". */
    static String abbreviation(Jutsu jutsu) {
        String[] words = shortName(jutsu).trim().split("\\s+");
        if (words.length >= 2 && !words[0].isEmpty() && !words[1].isEmpty()) {
            return ("" + words[0].charAt(0) + words[words.length - 1].charAt(0)).toUpperCase();
        }
        String w = words[0];
        return w.length() >= 2 ? w.substring(0, 1).toUpperCase() + w.charAt(1) : w.toUpperCase();
    }
}
