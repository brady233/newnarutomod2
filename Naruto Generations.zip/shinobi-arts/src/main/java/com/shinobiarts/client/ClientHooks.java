package com.shinobiarts.client;

import net.minecraft.client.Minecraft;

/** Client-only entry points that common code may call through DistExecutor. */
public final class ClientHooks {
    private ClientHooks() {}

    public static void openWallet() {
        Minecraft.getInstance().setScreen(new WalletScreen());
    }

    public static void openStats() {
        Minecraft.getInstance().setScreen(new StatScreen());
    }

    /**
     * Applies a data sync from the server, and flashes the Sharingan across the screen when the eyes are
     * switched on or evolve (not on the first sync after joining).
     */
    public static void applySync(net.minecraft.nbt.CompoundTag tag) {
        com.shinobiarts.ninja.NinjaData before = ClientNinjaData.get();
        boolean known = before.isInitialized();
        boolean wasOn = before.isSharinganActive();
        int oldStage = before.getSharinganStage();
        ClientNinjaData.apply(tag);
        com.shinobiarts.ninja.NinjaData now = ClientNinjaData.get();
        if (!known || now.getSharinganStage() <= 0) return;
        if ((now.isSharinganActive() && !wasOn) || now.getSharinganStage() > oldStage) {
            SharinganFlash.play(now.getSharinganStage());
        }
    }
}
