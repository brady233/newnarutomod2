package com.shinobiarts.registry;

import com.shinobiarts.ShinobiArts;
import com.shinobiarts.entity.ExplosiveTagEntity;
import com.shinobiarts.entity.JutsuProjectile;
import com.shinobiarts.entity.ShadowClone;
import com.shinobiarts.entity.ThrownToolEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, ShinobiArts.MODID);

    public static final RegistryObject<EntityType<JutsuProjectile>> JUTSU_PROJECTILE = ENTITIES.register("jutsu_projectile",
            () -> EntityType.Builder.<JutsuProjectile>of(JutsuProjectile::new, MobCategory.MISC)
                    .sized(0.6f, 0.6f)
                    .clientTrackingRange(6)
                    .updateInterval(10)
                    .build(ShinobiArts.id("jutsu_projectile").toString()));

    public static final RegistryObject<EntityType<ThrownToolEntity>> THROWN_TOOL = ENTITIES.register("thrown_tool",
            () -> EntityType.Builder.<ThrownToolEntity>of(ThrownToolEntity::new, MobCategory.MISC)
                    .sized(0.3f, 0.3f)
                    .clientTrackingRange(4)
                    .updateInterval(10)
                    .build(ShinobiArts.id("thrown_tool").toString()));

    public static final RegistryObject<EntityType<ExplosiveTagEntity>> EXPLOSIVE_TAG = ENTITIES.register("explosive_tag",
            () -> EntityType.Builder.<ExplosiveTagEntity>of(ExplosiveTagEntity::new, MobCategory.MISC)
                    .sized(0.3f, 0.3f)
                    .clientTrackingRange(4)
                    .updateInterval(10)
                    .build(ShinobiArts.id("explosive_tag").toString()));

    public static final RegistryObject<EntityType<ShadowClone>> SHADOW_CLONE = ENTITIES.register("shadow_clone",
            () -> EntityType.Builder.<ShadowClone>of(ShadowClone::new, MobCategory.MISC)
                    .sized(0.6f, 1.8f)
                    .clientTrackingRange(8)
                    .build(ShinobiArts.id("shadow_clone").toString()));

    private ModEntities() {}
}
