"""
Draws all the Sharingan art in a sharp anime style (pointed almond eyes, heavy upper lid, big red iris):
  textures/models/eyes/sharingan_<1-4>.png  - eyes drawn on the face of a player/clone with the Sharingan on
                                              (2048x1024 = the 64x32 armor layout x32; transparent except the eyes)
                                              1-3 = tomoe, 4 = Mangekyou
  textures/models/armor/sharingan.png       - the Sharingan helmet (3 tomoe; shows the wearer's own stage if active)
  textures/gui/sharingan_flash_<1-4>.png    - the big pair of eyes that flashes across the screen
  textures/item/sharingan.png               - Sharingan helmet icon
  textures/item/sharingan_eye.png           - a taken Sharingan eye
Eyes sit where most skins have them (Steve's eye row). Run: python3 tools/make_sharingan.py
"""
import math
import os

from PIL import Image, ImageDraw

HERE = os.path.dirname(os.path.abspath(__file__))
ASSETS = os.path.join(HERE, "..", "src", "main", "resources", "assets", "shinobiarts")
EYES = os.path.join(ASSETS, "textures", "models", "eyes")
ARMOR = os.path.join(ASSETS, "textures", "models", "armor")
GUI = os.path.join(ASSETS, "textures", "gui")
ITEM = os.path.join(ASSETS, "textures", "item")

SCALE = 32              # texture pixels per skin pixel in the face textures
SS = 3                  # supersampling
FACE_U, FACE_V = 8, 8   # the head's front face in the 64x32 armor layout

RED, RED_DARK, RED_LIGHT = (205, 16, 24), (105, 4, 10), (240, 60, 60)
INK, WHITE, WHITE_SHADE = (12, 6, 8), (250, 248, 246), (214, 208, 210)


def bezier(p0, p1, p2, n=24):
    return [((1 - t) ** 2 * p0[0] + 2 * (1 - t) * t * p1[0] + t * t * p2[0],
             (1 - t) ** 2 * p0[1] + 2 * (1 - t) * t * p1[1] + t * t * p2[1]) for t in (i / n for i in range(n + 1))]


def eye_shape(cx, cy, w, h, inner_left):
    """Pointed almond: upper lid arches high, lower lid is flatter; the inner corner sits a little lower."""
    s = -1 if inner_left else 1      # +1: inner corner on the right (the viewer's left eye)
    inner = (cx + s * w / 2, cy + h * 0.12)
    outer = (cx - s * w / 2, cy - h * 0.08)
    upper = bezier(inner, (cx + s * w * 0.05, cy - h * 1.05), outer)
    lower = bezier(outer, (cx - s * w * 0.05, cy + h * 0.78), inner)
    return upper, lower, inner, outer


def draw_iris(d, cx, cy, r, stage):
    for i in range(14, 0, -1):  # radial gradient: dark rim to bright middle
        t = i / 14
        col = tuple(round(RED_DARK[k] + (RED[k] - RED_DARK[k]) * (1 - t) ** 0.6) for k in range(3))
        d.ellipse([cx - r * t, cy - r * t, cx + r * t, cy + r * t], fill=col)
    d.ellipse([cx - r, cy - r, cx + r, cy + r], outline=INK, width=max(2, round(r * 0.11)))
    if stage == 4:
        draw_mangekyou(d, cx, cy, r)
    else:
        tr = r * 0.58
        d.ellipse([cx - tr, cy - tr, cx + tr, cy + tr], outline=(55, 0, 4), width=max(1, round(r * 0.05)))
        for k in range(stage):
            a = math.radians(-90 + k * (360 / stage if stage > 1 else 0))
            dot = r * 0.16
            for sidx in range(12):  # the comma's tail, sweeping along the ring
                b = a + math.radians(6 + sidx * 5)
                wdt = dot * (1 - sidx / 12) ** 1.2
                px, py = cx + tr * math.cos(b), cy + tr * math.sin(b)
                d.ellipse([px - wdt, py - wdt, px + wdt, py + wdt], fill=INK)
            tx, ty = cx + tr * math.cos(a), cy + tr * math.sin(a)
            d.ellipse([tx - dot, ty - dot, tx + dot, ty + dot], fill=INK)
        p = r * 0.2
        d.ellipse([cx - p, cy - p, cx + p, cy + p], fill=INK)
    h = r * 0.09
    d.ellipse([cx - r * 0.4 - h, cy - r * 0.42 - h, cx - r * 0.4 + h, cy - r * 0.42 + h], fill=(255, 205, 205))


def draw_mangekyou(d, cx, cy, r):
    """A three-bladed pinwheel (in the style of the Mangekyou) around a black center."""
    for k in range(3):
        a0 = math.radians(-90 + k * 120)
        pts = []
        for i in range(17):      # leading edge: center -> rim, curving
            t = i / 16
            ang = a0 + math.radians(75) * t ** 0.8
            rad = r * (0.22 + 0.72 * t)
            pts.append((cx + rad * math.cos(ang), cy + rad * math.sin(ang)))
        for i in range(17):      # trailing edge: rim -> center, curving the other way
            t = 1 - i / 16
            ang = a0 + math.radians(75) * t ** 0.8 + math.radians(48) * (1 - t) ** 0.5 * (t > 0)
            rad = r * (0.22 + 0.62 * t)
            pts.append((cx + rad * math.cos(ang + math.radians(30) * (1 - t)), cy + rad * math.sin(ang + math.radians(30) * (1 - t))))
        d.polygon(pts, fill=INK)
    c = r * 0.3
    d.ellipse([cx - c, cy - c, cx + c, cy + c], fill=INK)
    dot = r * 0.08
    d.ellipse([cx - dot, cy - dot, cx + dot, cy + dot], fill=RED)


def draw_eye(img, cx, cy, w, h, inner_left, stage, lids=1.0):
    """One eye onto an RGBA image (all sizes in pixels)."""
    d = ImageDraw.Draw(img)
    upper, lower, inner, outer = eye_shape(cx, cy, w, h, inner_left)
    shape = upper + lower
    # white of the eye, slightly shaded under the upper lid
    d.polygon(shape, fill=WHITE + (255,))
    shade = [(x, y + h * 0.18) for x, y in upper]
    mask = Image.new("L", img.size, 0)
    ImageDraw.Draw(mask).polygon(shape, fill=255)
    layer = Image.new("RGBA", img.size, (0, 0, 0, 0))
    ImageDraw.Draw(layer).polygon(upper + shade[::-1], fill=WHITE_SHADE + (255,))
    draw_iris(ImageDraw.Draw(layer), cx + (w * 0.02 if inner_left else -w * 0.02), cy + h * 0.05, h * 0.62, stage)
    img.paste(layer, (0, 0), Image.composite(layer.split()[3], Image.new("L", img.size, 0), mask))
    # inner corner (red)
    s = -1 if inner_left else 1
    d.polygon([inner, (inner[0] - s * w * 0.1, inner[1] - h * 0.16), (inner[0] - s * w * 0.1, inner[1] + h * 0.1)], fill=(190, 60, 60, 255))
    # heavy upper lid with a winged outer end, thin lower lid
    thick = h * 0.2 * lids
    band = []
    for i, (x, y) in enumerate(upper):
        t = i / (len(upper) - 1)                     # 0 at the inner corner, 1 at the outer corner
        band.append((x, y - thick * (0.35 + 0.65 * math.sin(math.pi * min(1.0, t * 1.1)))))
    wing = (outer[0] - s * w * 0.12, outer[1] - h * 0.18)
    d.polygon(upper + [wing] + band[::-1], fill=INK + (255,))
    d.line(lower, fill=INK + (255,), width=max(1, round(h * 0.07 * lids)))
    return upper


def face_texture(stage):
    unit = SCALE * SS
    img = Image.new("RGBA", (64 * unit, 32 * unit), (0, 0, 0, 0))
    for fx, inner_left in ((2.0, False), (6.0, True)):   # viewer's left eye has its inner corner on the right
        cx, cy = (FACE_U + fx) * unit, (FACE_V + 4.5) * unit
        draw_eye(img, cx, cy, 2.4 * unit, 1.15 * unit, inner_left, stage)
    return img.resize((64 * SCALE, 32 * SCALE), Image.LANCZOS)


def flash_texture(stage):
    w, h = 512 * SS, 160 * SS
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    for cx, inner_left in ((w * 0.27, False), (w * 0.73, True)):
        ew, eh = w * 0.36, h * 0.44
        cy = h * 0.64
        upper = draw_eye(img, cx, cy, ew, eh, inner_left, stage, lids=1.2)
        s = -1 if inner_left else 1
        # crease above the lid, and a sharp brow sloping down toward the nose
        crease = [(x, y - eh * 0.3) for x, y in upper[2:-6]]
        d.line(crease, fill=INK + (200,), width=round(eh * 0.05))
        brow_in = (cx + s * ew * 0.5, cy - eh * 0.98)
        brow_out = (cx - s * ew * 0.52, cy - eh * 1.12)
        d.polygon([brow_in, (brow_in[0] - s * ew * 0.04, brow_in[1] - eh * 0.2), (cx, cy - eh * 1.34), brow_out,
                   (cx - s * ew * 0.04, cy - eh * 1.14)], fill=INK + (235,))
    return img.resize((512, 160), Image.LANCZOS)


def helmet_icon():
    s = 32 * 8
    img = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    draw_eye(img, s / 2, s * 0.54, s * 0.92, s * 0.44, False, 3, lids=1.1)
    return img.resize((32, 32), Image.LANCZOS)


def eye_item_icon():
    s = 32 * 8
    img = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    r = s * 0.42
    cx, cy = s / 2, s / 2
    for i in range(16, 0, -1):  # eyeball: white with soft shading
        t = i / 16
        v = round(196 + 58 * (1 - t))
        d.ellipse([cx - r * t + s * 0.03 * (1 - t), cy - r * t - s * 0.03 * (1 - t),
                   cx + r * t + s * 0.03 * (1 - t), cy + r * t - s * 0.03 * (1 - t)], fill=(v, v - 6, v - 6, 255))
    d.ellipse([cx - r, cy - r, cx + r, cy + r], outline=(120, 60, 60, 255), width=round(s * 0.025))
    for ang in (200, 250, 300, 20, 110):  # a few veins
        a = math.radians(ang)
        d.line([(cx + r * 0.95 * math.cos(a), cy + r * 0.95 * math.sin(a)),
                (cx + r * 0.62 * math.cos(a + 0.2), cy + r * 0.62 * math.sin(a + 0.2))], fill=(200, 60, 60, 255), width=round(s * 0.012))
    draw_iris(d, cx - s * 0.02, cy + s * 0.01, r * 0.55, 3)
    return img.resize((32, 32), Image.LANCZOS)


def main():
    for folder in (EYES, ARMOR, GUI):
        os.makedirs(folder, exist_ok=True)
    for stage in range(1, 5):
        face_texture(stage).save(os.path.join(EYES, f"sharingan_{stage}.png"))
        flash_texture(stage).save(os.path.join(GUI, f"sharingan_flash_{stage}.png"))
    face_texture(3).save(os.path.join(ARMOR, "sharingan.png"))
    helmet_icon().save(os.path.join(ITEM, "sharingan.png"))
    eye_item_icon().save(os.path.join(ITEM, "sharingan_eye.png"))
    print("sharingan art written")


if __name__ == "__main__":
    main()
