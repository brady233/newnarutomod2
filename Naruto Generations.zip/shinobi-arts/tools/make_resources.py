"""Generates lang, models, recipes and damage types from Jutsus.java. Run: python3 tools/make_resources.py"""
import json
import math
import os
import re

HERE = os.path.dirname(os.path.abspath(__file__))
PROJECT = os.path.join(HERE, "..")
RES = os.path.join(PROJECT, "src", "main", "resources")
ASSETS = os.path.join(RES, "assets", "shinobiarts")
DATA = os.path.join(RES, "data", "shinobiarts")
MODID = "shinobiarts"

NATURES = ["fire", "water", "wind", "lightning", "earth", "yin_yang"]
RELEASES = NATURES + ["ninjutsu"]
NATURE_NAMES = {"fire": "Fire Release", "water": "Water Release", "wind": "Wind Release",
                "lightning": "Lightning Release", "earth": "Earth Release", "yin_yang": "Yin Yang Release",
                "ninjutsu": "Ninjutsu"}
CATALYST = {"fire": "minecraft:blaze_powder", "water": "minecraft:prismarine_shard", "wind": "minecraft:feather",
            "lightning": "minecraft:copper_ingot", "earth": "minecraft:clay_ball",
            "yin_yang": "minecraft:amethyst_shard",
            "ninjutsu": "minecraft:lapis_lazuli"}
# Extra ingredient for elemental jutsu scrolls (unchanged from before jutsu had ranks, so recipes stay the same):
# the weakest jutsu of each element needs nothing extra, the middle one a gold ingot, the strongest a diamond.
RECIPE_EXTRA = {
    "fireball": None, "phoenix_flower": "minecraft:gold_ingot", "fire_annihilation": "minecraft:diamond",
    "water_bullet": None, "water_prison": "minecraft:gold_ingot", "water_dragon": "minecraft:diamond",
    "gale_palm": None, "vacuum_blade": "minecraft:gold_ingot", "great_breakthrough": "minecraft:diamond",
    "lightning_armor": None, "chidori": "minecraft:gold_ingot", "thunder_strike": "minecraft:diamond",
    "earth_wall": None, "rock_armor": "minecraft:gold_ingot", "earth_spikes": "minecraft:diamond",
}
RANK_NAMES = {"D": "D-Rank", "C": "C-Rank", "B": "B-Rank", "A": "A-Rank", "S": "S-Rank"}

JUTSU_TEXT = {
    "fireball": ("Fire Release: Great Fireball", "Launches a huge ball of fire that bursts into flames on impact."),
    "phoenix_flower": ("Fire Release: Phoenix Flower", "Fires a fan of five small fireballs that set targets ablaze."),
    "fire_annihilation": ("Fire Release: Great Fire Annihilation", "Breathes a sea of fire across a wide cone in front of you."),
    "water_bullet": ("Water Release: Water Bullet", "A fast, hard-hitting shot of water that knocks enemies back."),
    "water_prison": ("Water Release: Water Prison", "Traps the creature you're looking at in water, holding it nearly still."),
    "water_dragon": ("Water Release: Water Dragon", "A surging dragon of water that crashes down on everything near its impact."),
    "gale_palm": ("Wind Release: Gale Palm", "A blast of wind that throws enemies back and turns aside projectiles."),
    "vacuum_blade": ("Wind Release: Vacuum Blade", "An invisible blade of wind that cuts through every enemy in a line."),
    "great_breakthrough": ("Wind Release: Great Breakthrough", "A colossal gust that flattens plants and hurls everything in front of you away."),
    "lightning_armor": ("Lightning Release: Lightning Armor", "Coats your body in lightning: faster movement, attacks and mining for 20 seconds."),
    "chidori": ("Chidori", "Dash to the enemy you're looking at and strike with a crackling blade of lightning."),
    "thunder_strike": ("Lightning Release: Thunder Strike", "Calls down a lightning bolt where you're looking."),
    "earth_wall": ("Earth Release: Earth Wall", "Raises a wall of earth in front of you. It crumbles after about 15 seconds."),
    "rock_armor": ("Earth Release: Rock Armor", "Hardens your body like stone for 20 seconds: strong damage resistance, but slower."),
    "earth_spikes": ("Earth Release: Rising Spikes", "The ground erupts where you're looking, launching enemies into the air."),
    "substitution": ("Substitution Jutsu", "For 6 seconds, the next attack hits a log instead and you vanish a few blocks away."),
    "body_flicker": ("Body Flicker", "Move in a blur to the spot you're looking at (up to 16 blocks)."),
    "shadow_clone": ("Shadow Clone Jutsu", "Creates solid copies of yourself that fight beside you for 30 seconds. Any hit dispels them."),
    "rasengan": ("Rasengan", "Spin chakra into a sphere in your hand. Your next punch deals huge damage and sends the target flying."),
    "shadow_possession": ("Shadow Possession", "Stretches your shadow to bind a target in place for 6 seconds. You're slowed while holding it."),
    "palm_rotation": ("Eight Trigrams Palm Rotation", "Spin chakra around you to repel everything nearby and block all attacks for a moment."),
    "amaterasu": ("Amaterasu", "Black flames that burn a target for 10 seconds and can't be put out. Needs an active Sharingan."),
    "hell_viewing": ("Yin Release: Hell Viewing", "Traps the target you're looking at in a nightmare: blinded and staggering. Longer with Genjutsu."),
    "mind_fog": ("Yin Release: Mind Fog", "Casts an illusion on everything around you, leaving them lost and slowed. Longer with Genjutsu."),
    "mystical_palm": ("Yang Release: Mystical Palm", "Heals the player you're looking at, or yourself. Heals more with Medical."),
    "rasenshuriken": ("Wind Release: Rasenshuriken", "Throws a spinning shuriken of wind chakra that bursts into a sphere of blades, shredding everything around it."),
    "vitality_surge": ("Yang Release: Vitality Surge", "Floods your body with life: strong regeneration, extra hearts, and cures poison. Longer with Medical."),
}

# Shapeless recipe ingredients for each jutsu scroll (besides the blank scroll).
SPECIAL_RECIPES = {
    "substitution": [{"tag": "minecraft:logs"}, "minecraft:lapis_lazuli"],
    "body_flicker": ["minecraft:feather", "minecraft:sugar"],
    "shadow_clone": ["minecraft:lapis_lazuli", "minecraft:lapis_lazuli", "minecraft:gold_ingot"],
    "rasengan": ["minecraft:lapis_lazuli", "minecraft:lapis_lazuli", "minecraft:diamond"],
    "shadow_possession": ["minecraft:ink_sac", "minecraft:ink_sac", "minecraft:gold_ingot"],
    "palm_rotation": ["minecraft:quartz", "minecraft:quartz", "minecraft:gold_ingot"],
    "amaterasu": ["minecraft:ink_sac", "minecraft:blaze_powder", "minecraft:ender_eye", "minecraft:diamond"],
    # Yin Yang: Yin jutsu use fermented spider eyes, Yang jutsu use glistering melon
    "hell_viewing": ["minecraft:fermented_spider_eye", "minecraft:fermented_spider_eye"],
    "mind_fog": ["minecraft:fermented_spider_eye", "minecraft:fermented_spider_eye", "minecraft:gold_ingot"],
    "mystical_palm": ["minecraft:glistering_melon_slice", "minecraft:glistering_melon_slice"],
    "vitality_surge": ["minecraft:glistering_melon_slice", "minecraft:glistering_melon_slice", "minecraft:gold_ingot"],
    "rasenshuriken": ["minecraft:feather", "minecraft:feather", "minecraft:lapis_lazuli", "minecraft:diamond"],
}


def write_json(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        json.dump(obj, f, indent=2)
        f.write("\n")


def parse_jutsus():
    src = open(os.path.join(PROJECT, "src", "main", "java", "com", "shinobiarts", "jutsu", "Jutsus.java")).read()
    out = []
    for m in re.finditer(r'reg\("(\w+)",\s*(\w+),\s*(null|Clan\.\w+),\s*([DCBAS]),', src):
        jid, nature, clan, rank = m.group(1), m.group(2).lower(), m.group(3), m.group(4)
        clan = None if clan == "null" else clan.split(".")[1].lower()
        out.append({"id": jid, "nature": nature, "clan": clan, "rank": rank})
    return out


def ingredient(spec):
    return spec if isinstance(spec, dict) else {"item": spec}


def shapeless(name, ingredients, result, count=1, category="misc"):
    write_json(os.path.join(DATA, "recipes", name + ".json"), {
        "type": "minecraft:crafting_shapeless",
        "category": category,
        "ingredients": [ingredient(i) for i in ingredients],
        "result": {"item": result, "count": count},
    })
    return tuple(sorted(json.dumps(ingredient(i), sort_keys=True) for i in ingredients))


def shaped(name, pattern, key, result, count=1, category="equipment"):
    write_json(os.path.join(DATA, "recipes", name + ".json"), {
        "type": "minecraft:crafting_shaped",
        "category": category,
        "pattern": pattern,
        "key": {k: ingredient(v) for k, v in key.items()},
        "result": {"item": result, "count": count},
    })


def item_model(name, texture, parent="minecraft:item/generated"):
    write_json(os.path.join(ASSETS, "models", "item", name + ".json"),
               {"parent": parent, "textures": {"layer0": MODID + ":item/" + texture}})


# Vanilla-style hand transforms, adjusted for each 3D model (see tools/convert_models.py for the layout).
HANDHELD = {
    "thirdperson_righthand": {"rotation": [0, -90, 55], "translation": [0, 4.0, 0.5], "scale": [0.85, 0.85, 0.85]},
    "thirdperson_lefthand": {"rotation": [0, 90, -55], "translation": [0, 4.0, 0.5], "scale": [0.85, 0.85, 0.85]},
    "firstperson_righthand": {"rotation": [0, -90, 25], "translation": [1.13, 3.2, 1.13], "scale": [0.68, 0.68, 0.68]},
    "firstperson_lefthand": {"rotation": [0, 90, -25], "translation": [1.13, 3.2, 1.13], "scale": [0.68, 0.68, 0.68]},
    "ground": {"rotation": [0, 0, 0], "translation": [0, 2, 0], "scale": [0.5, 0.5, 0.5]},
    "head": {"rotation": [0, 180, 0], "translation": [0, 13, 7], "scale": [1, 1, 1]},
    "fixed": {"rotation": [0, 180, 0], "translation": [0, 0, 0], "scale": [1, 1, 1]},
}
HELD_ITEM = {
    "thirdperson_righthand": {"rotation": [0, 0, 0], "translation": [0, 3, 1], "scale": [0.55, 0.55, 0.55]},
    "firstperson_righthand": {"rotation": [0, -90, 25], "translation": [1.13, 3.2, 1.13], "scale": [0.68, 0.68, 0.68]},
    "ground": {"rotation": [0, 0, 0], "translation": [0, 2, 0], "scale": [0.5, 0.5, 0.5]},
    "head": {"rotation": [0, 180, 0], "translation": [0, 13, 7], "scale": [1, 1, 1]},
    "fixed": {"rotation": [0, 180, 0], "translation": [0, 0, 0], "scale": [1, 1, 1]},
}
KUNAI_DISPLAY = json.loads(json.dumps(HANDHELD))
for k in ("thirdperson_righthand", "thirdperson_lefthand"):
    KUNAI_DISPLAY[k]["scale"] = [0.7, 0.7, 0.7]
for k in ("firstperson_righthand", "firstperson_lefthand"):
    KUNAI_DISPLAY[k]["scale"] = [0.55, 0.55, 0.55]
VANILLA_GRIP = 0.16  # where the hand holds a vanilla sword sprite (x = y, in block units)


def _grip_offset(rotation, scale, grip):
    """Where a model point at (grip, grip, 0.5) ends up after an item transform (translation excluded)."""
    d = scale * (grip - 0.5)
    v = [d, d, 0.0]
    rx, ry, rz = (math.radians(a) for a in rotation)
    # Minecraft applies Quaternionf.rotationXYZ: Rz first, then Ry, then Rx.
    v = [v[0] * math.cos(rz) - v[1] * math.sin(rz), v[0] * math.sin(rz) + v[1] * math.cos(rz), v[2]]
    v = [v[0] * math.cos(ry) + v[2] * math.sin(ry), v[1], -v[0] * math.sin(ry) + v[2] * math.cos(ry)]
    v = [v[0], v[1] * math.cos(rx) - v[2] * math.sin(rx), v[1] * math.sin(rx) + v[2] * math.cos(rx)]
    return v


def _matmul(a, b):
    return [[sum(a[i][k] * b[k][j] for k in range(3)) for j in range(3)] for i in range(3)]


def _rot_matrix(rotation):
    """The matrix Minecraft builds from a display rotation [x, y, z] (Quaternionf.rotationXYZ = Rx * Ry * Rz)."""
    rx, ry, rz = (math.radians(a) for a in rotation)
    mx = [[1, 0, 0], [0, math.cos(rx), -math.sin(rx)], [0, math.sin(rx), math.cos(rx)]]
    my = [[math.cos(ry), 0, math.sin(ry)], [0, 1, 0], [-math.sin(ry), 0, math.cos(ry)]]
    mz = [[math.cos(rz), -math.sin(rz), 0], [math.sin(rz), math.cos(rz), 0], [0, 0, 1]]
    return _matmul(mx, _matmul(my, mz))


def _euler_xyz(m):
    """Inverse of _rot_matrix: display rotation angles (degrees) for a rotation matrix."""
    b = math.asin(max(-1.0, min(1.0, m[0][2])))
    a = math.atan2(-m[1][2], m[2][2])
    c = math.atan2(-m[0][1], m[0][0])
    return [round(math.degrees(x), 2) for x in (a, b, c)]


def _apply(rotation, v):
    m = _rot_matrix(rotation)
    return [sum(m[i][k] * v[k] for k in range(3)) for i in range(3)]


def _spin_about_blade(rotation, degrees):
    """Adds a turn around the weapon's own long axis (the model's diagonal) before the display rotation."""
    u = [1 / math.sqrt(2), 1 / math.sqrt(2), 0.0]
    c, s_, t = math.cos(math.radians(degrees)), math.sin(math.radians(degrees)), 1 - math.cos(math.radians(degrees))
    x, y, z = u
    spin = [[c + x * x * t, x * y * t - z * s_, x * z * t + y * s_],
            [y * x * t + z * s_, c + y * y * t, y * z * t - x * s_],
            [z * x * t - y * s_, z * y * t + x * s_, c + z * z * t]]
    return _euler_xyz(_matmul(_rot_matrix(rotation), spin))


def weapon_display(grip, third_scale, first_scale, ground_scale, spin=0):
    """
    Hand transforms for a weapon laid out by tools/convert_models.py with its grip at (grip, grip).
    The translation is solved so the grip lands exactly where a vanilla sword's handle is held,
    whatever the weapon's size. `grip` must match the second "grip" number in convert_models.MODELS.
    `spin` turns the weapon around its own long axis in the hand (e.g. 180 to flip which way a scythe's blades face);
    the grip stays in place because it lies on that axis.
    """
    display = json.loads(json.dumps(HANDHELD))
    for view, scale in (("thirdperson", third_scale), ("firstperson", first_scale)):
        for hand, sign in (("righthand", 1), ("lefthand", -1)):
            t = display[f"{view}_{hand}"]
            rot = HANDHELD[f"{view}_righthand"]["rotation"]
            vanilla = HANDHELD[f"{view}_righthand"]
            want = [vanilla["translation"][i] / 16 + o for i, o in
                    enumerate(_grip_offset(rot, vanilla["scale"][0], VANILLA_GRIP))]
            got = _grip_offset(rot, scale, grip)
            t["translation"] = [round(vanilla["translation"][0], 2)] + [round((want[i] - got[i]) * 16, 2) for i in (1, 2)]
            t["scale"] = [scale] * 3
            if spin:
                r = _spin_about_blade(rot, spin)
                t["rotation"] = [r[0], r[1] * sign, r[2] * sign]
    display["ground"]["scale"] = [ground_scale] * 3
    return display


def vanilla_grip_point(view):
    """Where a vanilla sword's handle is held, in the item's frame for this view (block units)."""
    v = HANDHELD[f"{view}_righthand"]
    return [v["translation"][i] / 16 + o for i, o in enumerate(_grip_offset(v["rotation"], v["scale"][0], VANILLA_GRIP))]


def scroll_display():
    """
    Rolled scrolls are held in the fist, a little below their middle, so most of the scroll shows above the hand.
    Third person: the fist sits exactly where the hand grips a sword; the scroll points forward and up (so it is
    visible from the front and the side). First person: it rises out of the bottom-right of the screen.
    """
    display = json.loads(json.dumps(HELD_ITEM))
    diag = [1 / math.sqrt(2), 1 / math.sqrt(2), 0.0]
    for view, rot, scale, along in (("thirdperson", [55, 90, 45], 0.8, 0.12), ("firstperson", [0, -90, 25], 0.72, 0.15)):
        grip = vanilla_grip_point(view)
        axis = _apply(rot, diag)  # unit vector along the scroll, after rotation
        centre = [grip[i] + along * axis[i] for i in range(3)]
        x = HANDHELD[f"{view}_righthand"]["translation"][0] / 16 if view == "firstperson" else 0.0
        for hand, sign in (("righthand", 1), ("lefthand", -1)):
            display[f"{view}_{hand}"] = {"rotation": [rot[0], rot[1] * sign, rot[2] * sign],
                                         "translation": [round(x * 16, 2), round(centre[1] * 16, 2), round(centre[2] * 16, 2)],
                                         "scale": [scale] * 3}
    return display


SCROLL_DISPLAY = scroll_display()
# name: (grip, third-person scale, first-person scale, ground scale)
WEAPONS = {
    "zabuza_blade": (0.14, 0.9, 0.5, 0.3),
    "samehada": (0.14, 0.9, 0.5, 0.3),
    "hidan_scythe": (0.14, 0.85, 0.55, 0.35, 180),  # turned over so the blades hang down
    "shakujo": (0.2, 0.85, 0.55, 0.35),
    "sword_of_fire": (0.15, 0.85, 0.62, 0.45),
    "kusanagi": (0.16, 0.85, 0.68, 0.5),
    "katana": (0.16, 0.85, 0.68, 0.5),
}


def obj_model(name, display, obj=None, textures=None):
    """
    models/item/3d/<name>.json: a converted OBJ with its textures and hand transforms.
    `obj` reuses another model's OBJ file, and `textures` replaces its textures (in material order).
    """
    obj = obj or name
    mtl = open(os.path.join(ASSETS, "models", "item", "obj", obj + ".mtl")).read()
    keys = re.findall(r"newmtl (\w+)", mtl)
    names = textures or [f"{obj}_{i}" for i in range(len(keys))]
    textures = {k: f"{MODID}:item/model/{names[i]}" for i, k in enumerate(keys)}
    textures["particle"] = textures[keys[0]]
    write_json(os.path.join(ASSETS, "models", "item", "3d", name + ".json"), {
        "loader": "forge:obj",
        "model": f"{MODID}:models/item/obj/{obj}.obj",
        "flip_v": False,
        "automatic_culling": False,
        "shade_quads": True,
        "emissive_ambient": True,
        "render_type": "minecraft:cutout",
        "textures": textures,
        "display": display,
    })


def icon_model(name, texture, parent="minecraft:item/generated"):
    """models/item/icon/<name>.json: a flat sprite used for the inventory icon."""
    write_json(os.path.join(ASSETS, "models", "item", "icon", name + ".json"),
               {"parent": parent, "textures": {"layer0": MODID + ":item/" + texture}})


def item_3d(item, model3d, icon_texture):
    """The item's model: 3D everywhere except the inventory/item frames, which show the flat icon."""
    icon_model(item, icon_texture)
    write_json(os.path.join(ASSETS, "models", "item", item + ".json"), {
        "loader": "forge:separate_transforms",
        "gui_light": "front",
        "base": {"parent": f"{MODID}:item/3d/{model3d}"},
        "perspectives": {
            "gui": {"parent": f"{MODID}:item/icon/{item}"},
            "fixed": {"parent": f"{MODID}:item/icon/{item}"},
        },
    })


def short_name(full):
    return full.split(": ", 1)[1] if ": " in full else full


def main():
    jutsus = parse_jutsus()
    assert len(jutsus) == len(JUTSU_TEXT), (len(jutsus), sorted(set(j["id"] for j in jutsus) ^ set(JUTSU_TEXT)))

    lang = {
        "itemGroup.shinobiarts": "Naruto Generations",
        "item.shinobiarts.kunai": "Kunai",
        "item.shinobiarts.shuriken": "Shuriken",
        "item.shinobiarts.explosive_tag": "Explosive Tag",
        "item.shinobiarts.chakra_pill": "Chakra Pill",
        "item.shinobiarts.chakra_paper": "Chakra Paper",
        "item.shinobiarts.blank_scroll": "Blank Scroll",
        "item.shinobiarts.exp_bottle": "Ninja EXP Bottle",
        "item.shinobiarts.frog_wallet": "Frog Wallet",
        "item.shinobiarts.bronze_ryo": "Bronze Ryo",
        "item.shinobiarts.silver_ryo": "Silver Ryo",
        "item.shinobiarts.gold_ryo": "Gold Ryo",
        "item.shinobiarts.zabuza_blade": "Kubikiribocho",
        "item.shinobiarts.samehada": "Samehada",
        "item.shinobiarts.hidan_scythe": "Hidan's Triple-Bladed Scythe",
        "item.shinobiarts.sword_of_fire": "Sword of Fire",
        "item.shinobiarts.shakujo": "Shakujo Staff",
        "item.shinobiarts.kusanagi": "Kusanagi Sword",
        "item.shinobiarts.katana": "Katana",
        "item.shinobiarts.sharingan": "Sharingan",
        "item.shinobiarts.sharingan_eye": "Sharingan Eye",
        "item.shinobiarts.xp_boost_1_5x_30m": "XP Boost Token (1.5x, 30 min)",
        "item.shinobiarts.xp_boost_1_5x_60m": "XP Boost Token (1.5x, 1 hour)",
        "item.shinobiarts.xp_boost_2_5x_30m": "XP Boost Token (2.5x, 30 min)",
        "item.shinobiarts.xp_boost_2_5x_60m": "XP Boost Token (2.5x, 1 hour)",
        "container.shinobiarts.vault": "Vault",

        "sharingan.shinobiarts.stage1": "1-Tomoe Sharingan",
        "sharingan.shinobiarts.stage2": "2-Tomoe Sharingan",
        "sharingan.shinobiarts.stage3": "3-Tomoe Sharingan",
        "sharingan.shinobiarts.stage4": "Mangekyou Sharingan",
        "message.shinobiarts.sharingan_evolved": "Your Sharingan evolved: %s!",
        "message.shinobiarts.mangekyou_awakened": "Staring death in the face, your eyes awaken the %s!",
        "message.shinobiarts.eye_taken": "You took %s's eye (%s). Right-click it to implant it.",
        "message.shinobiarts.eye_lost": "%s took your Sharingan!",
        "message.shinobiarts.eye_no_better": "Your own eyes are already this strong.",
        "message.shinobiarts.eye_too_strong": "This eye is too strong for you yet: reach level %s first.",
        "message.shinobiarts.eye_implanted": "You implanted the eye: you now have the %s.",
        "message.shinobiarts.eye_limited": "It will grow stronger as you level up (next stage at level %s).",
        "message.shinobiarts.needs_mangekyou": "Amaterasu needs an active Mangekyou Sharingan.",
        "message.shinobiarts.need_sharingan": "You need a Sharingan to learn this.",

        "message.shinobiarts.combat_start": "You're in combat with %s! Logging out in the next %s seconds will kill you.",
        "message.shinobiarts.combat_over": "You're no longer in combat.",
        "message.shinobiarts.combat_no_commands": "You can't use commands while in combat (%ss left).",
        "message.shinobiarts.combat_logged": "%s logged out during combat and was killed.",
        "hud.shinobiarts.combat": "In Combat (%s) - %s",

        "message.shinobiarts.boost_started": "XP boost active: x%s ninja XP for %s minutes.",
        "message.shinobiarts.boost_extended": "XP boost extended: x%s, %s minutes left.",
        "message.shinobiarts.boost_stronger": "A stronger boost (x%s) is already running.",
        "message.shinobiarts.boost_over": "Your XP boost ran out.",
        "hud.shinobiarts.boost": "XP x%s %s",

        "message.shinobiarts.team_already_in": "You're already in a team. Leave it first with /team leave.",
        "message.shinobiarts.team_bad_name": "Team names are 2-16 letters, numbers or _.",
        "message.shinobiarts.team_name_taken": "A team called %s already exists.",
        "message.shinobiarts.team_created": "Team %s created! Invite players with /team invite <player>.",
        "message.shinobiarts.team_none": "You're not in a team.",
        "message.shinobiarts.team_not_leader": "Only the team leader can do that.",
        "message.shinobiarts.team_invite_self": "You can't invite yourself.",
        "message.shinobiarts.team_target_in_team": "%s is already in a team.",
        "message.shinobiarts.team_full": "The team is full (%s players).",
        "message.shinobiarts.team_invited": "%s invited you to the team %s.",
        "message.shinobiarts.team_accept_button": "[Accept]",
        "message.shinobiarts.team_decline_button": "[Decline]",
        "message.shinobiarts.team_invite_sent": "Invite sent to %s.",
        "message.shinobiarts.team_no_invite": "You don't have a team invite.",
        "message.shinobiarts.team_joined": "%s joined %s!",
        "message.shinobiarts.team_declined": "Invite declined.",
        "message.shinobiarts.team_left": "%s left the team.",
        "message.shinobiarts.team_you_left": "You left %s.",
        "message.shinobiarts.team_no_member": "No member called %s.",
        "message.shinobiarts.team_kicked": "You were removed from %s.",
        "message.shinobiarts.team_disbanded": "Team %s was disbanded.",
        "message.shinobiarts.team_info": "Team %s (%s/%s):",
        "message.shinobiarts.team_new_leader": "%s is now the team leader.",
        "screen.shinobiarts.team": "Team",
        "screen.shinobiarts.team_members": "Members %s/%s",
        "screen.shinobiarts.team_none": "No team yet",
        "screen.shinobiarts.team_invite": "Invite from %s",
        "screen.shinobiarts.team_leave": "Leave Team",
        "itemGroup.shinobiarts.ninja_tools": "Naruto Generations: Ninja Tools",
        "block.shinobiarts.earth_wall": "Earth Wall",
        "entity.shinobiarts.jutsu_projectile": "Jutsu",
        "entity.shinobiarts.thrown_tool": "Thrown Weapon",
        "entity.shinobiarts.explosive_tag": "Explosive Tag",
        "entity.shinobiarts.shadow_clone": "Shadow Clone",
        "effect.shinobiarts.amaterasu": "Amaterasu",

        "clan.shinobiarts.none": "Clanless",
        "clan.shinobiarts.uchiha": "Uchiha",
        "clan.shinobiarts.hyuga": "Hyuga",
        "clan.shinobiarts.uzumaki": "Uzumaki",
        "clan.shinobiarts.nara": "Nara",
        "dojutsu.shinobiarts.uchiha": "Sharingan",
        "dojutsu.shinobiarts.hyuga": "Byakugan",
        "dojutsu.shinobiarts.none": "Dojutsu",
        "dojutsu.shinobiarts.uzumaki": "Dojutsu",
        "dojutsu.shinobiarts.nara": "Dojutsu",

        "key.categories.shinobiarts": "Naruto Generations",
        "key.shinobiarts.next": "Move jutsu arrow right",
        "key.shinobiarts.prev": "Move jutsu arrow left",
        "key.shinobiarts.dojutsu": "Toggle eye technique",
        "key.shinobiarts.charge": "Charge chakra (hold)",
        "key.shinobiarts.sage": "Toggle Sage Mode",
        "key.shinobiarts.stats": "Stats menu",

        "hud.shinobiarts.ready": "  Ready",
        "hud.shinobiarts.low_chakra": "  Low chakra",
        "hud.shinobiarts.charging": "Charging",
        "hud.shinobiarts.rasengan": "Rasengan",
        "hud.shinobiarts.substitution": "Substitution",
        "hud.shinobiarts.sage": "Sage Mode",
        "hud.shinobiarts.hold_release": "Hold a release scroll to use jutsu",
        "hud.shinobiarts.release_locked": "You can't use this release yet",
        "hud.shinobiarts.release_empty": "No jutsu learned in this release",

        "screen.shinobiarts.stats": "Ninja Stats",
        "screen.shinobiarts.level": "Level %s",
        "screen.shinobiarts.xp": "%s / %s XP",
        "screen.shinobiarts.max_level": "Max level",
        "screen.shinobiarts.points": "Stat points: %s",
        "screen.shinobiarts.ryo": "Ryo: %s",
        "screen.shinobiarts.shift_add": "Shift-click to add 5 points",
        "screen.shinobiarts.reset_button": "Reset Stats (%s Ryo)",
        "screen.shinobiarts.reset_title": "Reset Stats?",
        "screen.shinobiarts.reset_text": "All %s spent points will be refunded.",
        "screen.shinobiarts.reset_price": "Price: %s Ryo",
        "screen.shinobiarts.reset_balance": "You have: %s Ryo",
        "screen.shinobiarts.reset_confirm": "Reset",
        "screen.shinobiarts.wallet": "Frog Wallet",
        "screen.shinobiarts.deposit": "Deposit",
        "screen.shinobiarts.deposit_all": "Deposit All Coins",
        "screen.shinobiarts.coin_row": "x%s · %s each",
        "screen.shinobiarts.close": "Close",
        "screen.shinobiarts.rank": "%s (level cap %s)",
        "screen.shinobiarts.rank_capped": "Level cap reached: needs a promotion",
        "rank.shinobiarts.genin": "Genin",
        "rank.shinobiarts.chunin": "Chunin",
        "rank.shinobiarts.jonin": "Jonin",
        "rank.shinobiarts.anbu": "Anbu",
        "rank.shinobiarts.sannin": "Sannin",
        "message.shinobiarts.rank_cap": "You've reached the %s level cap (%s). XP is saved until you're promoted.",
        "message.shinobiarts.promoted": "Promoted to %s! Your level cap is now %s.",
        "message.shinobiarts.pvp_reward": "Defeated %s: +%s XP, +%s Ryo",
        "message.shinobiarts.pvp_too_weak": "No reward: %s is far weaker than you.",
        "message.shinobiarts.pvp_too_strong": "No reward: %s is far stronger than you.",
        "message.shinobiarts.pvp_recent": "No reward: you defeated %s recently.",
        "message.shinobiarts.pvp_inactive": "No reward: %s wasn't moving or fighting back.",

        "stat.shinobiarts.taijutsu": "Taijutsu",
        "stat.shinobiarts.taijutsu.desc": "Stronger punches (bare hands or holding a release scroll). Does not affect swords.",
        "stat.shinobiarts.kenjutsu": "Kenjutsu",
        "stat.shinobiarts.kenjutsu.desc": "More damage with swords, including Kubikiribocho.",
        "stat.shinobiarts.genjutsu": "Genjutsu",
        "stat.shinobiarts.genjutsu.desc": "Stronger Sharingan, Amaterasu, Shadow Possession and Yin illusions.",
        "stat.shinobiarts.medical": "Medical",
        "stat.shinobiarts.medical.desc": "More max health, and stronger Yang healing.",
        "stat.shinobiarts.speed": "Speed",
        "stat.shinobiarts.speed.desc": "Faster movement. The only stat with a cap (50 points).",
        "stat.shinobiarts.ninjutsu": "Ninjutsu",
        "stat.shinobiarts.ninjutsu.desc": "+5 max chakra per point, and slightly faster chakra regeneration.",
        "stat.shinobiarts.senjutsu": "Senjutsu",
        "stat.shinobiarts.senjutsu.desc": "Natural energy for Sage Mode (B). Gather it by charging chakra (Z) while standing still.",
        "stat.shinobiarts.effect.taijutsu": "+%s fist damage",
        "stat.shinobiarts.effect.kenjutsu": "+%s sword damage",
        "stat.shinobiarts.effect.genjutsu": "+%s%% genjutsu power",
        "stat.shinobiarts.effect.medical": "+%s max health",
        "stat.shinobiarts.effect.speed": "+%s%% speed",
        "stat.shinobiarts.effect.ninjutsu": "%s max chakra",
        "stat.shinobiarts.effect.senjutsu": "%s max senjutsu",

        "tooltip.shinobiarts.clan_only": "Clan technique: %s",
        "tooltip.shinobiarts.nature": "Nature: %s",
        "tooltip.shinobiarts.cost": "Chakra: %s  Cooldown: %ss",
        "tooltip.shinobiarts.requires_level": "Requires level %s",
        "tooltip.shinobiarts.rank": "%s Jutsu",
        "tooltip.shinobiarts.goes_to_release": "Goes into your %s slots",
        "tooltip.shinobiarts.release_hold": "Hold to equip this release's jutsu (right-click to cast, G/H move the arrow)",
        "tooltip.shinobiarts.release_locked": "You haven't unlocked this nature yet",
        "tooltip.shinobiarts.release_empty": "No jutsu learned yet: read jutsu scrolls to fill it",
        "tooltip.shinobiarts.coin": "Worth %s Ryo",
        "tooltip.shinobiarts.coin_stack": "Stack worth %s Ryo",
        "tooltip.shinobiarts.coin_hint": "Deposit with a Frog Wallet",
        "tooltip.shinobiarts.wallet": "Right-click to deposit or withdraw Ryo. Your Ryo stays safe even if you lose the wallet.",
        "tooltip.shinobiarts.exp_bottle": "Right-click for %s ninja XP (sneak to use the whole stack)",
        "tooltip.shinobiarts.weapon.self_repair": "Repairs itself with every hit",
        "tooltip.shinobiarts.weapon.chakra_drain": "Eats chakra: steals it from players and feeds you on every hit",
        "tooltip.shinobiarts.weapon.chidori_flow": "Chidori Flow: hits spend a little chakra to paralyse the target",
        "tooltip.shinobiarts.weapon.lifesteal": "Jashin's Ritual: heals you for part of the damage you deal",
        "tooltip.shinobiarts.weapon.burn": "Sets targets ablaze",
        "tooltip.shinobiarts.weapon.knockback": "Heavy strikes knock targets far back",
        "tooltip.shinobiarts.weapon.kenjutsu": "Boosted by Kenjutsu",
        "tooltip.shinobiarts.sharingan": "Wear it in your helmet slot to show the Sharingan in your eyes",
        "tooltip.shinobiarts.needs_dojutsu": "Learn: needs a Sharingan. Cast: needs an active Mangekyou Sharingan",
        "tooltip.shinobiarts.eye_from": "Taken from %s",
        "tooltip.shinobiarts.eye_implant": "Right-click to implant it",
        "tooltip.shinobiarts.xp_boost": "Right-click: x%s ninja XP from mobs and PvP for %s minutes (only counts down while you're online)",
        "tooltip.shinobiarts.known": "Already learned",
        "tooltip.shinobiarts.right_click_learn": "Right-click to learn",
        "tooltip.shinobiarts.nature_scroll": "Unlocks %s jutsu",
        "tooltip.shinobiarts.nature_scroll_req": "You must know your affinity first (use Chakra Paper).",
        "tooltip.shinobiarts.chakra_paper": "Right-click to discover your nature affinity.",
        "tooltip.shinobiarts.chakra_pill": "Restores %s chakra",
        "tooltip.shinobiarts.throwable": "Right-click to throw",
        "tooltip.shinobiarts.explosive_tag": "Throw it: sticks to blocks and explodes after 2 seconds.",

        "message.shinobiarts.no_target": "No target in sight.",
        "message.shinobiarts.no_room": "There's no room for that here.",
        "message.shinobiarts.hold_release": "Hold a release scroll to use its jutsu.",
        "message.shinobiarts.release_locked": "You haven't unlocked %s yet.",
        "message.shinobiarts.release_empty": "No jutsu in %s yet. Read a jutsu scroll to add one.",
        "message.shinobiarts.release_given": "You received the %s scroll.",
        "message.shinobiarts.cooldown": "%s is recharging (%ss)",
        "message.shinobiarts.needs_dojutsu": "This jutsu needs your %s active.",
        "message.shinobiarts.not_enough_chakra": "Not enough chakra (%s / %s)",
        "message.shinobiarts.sharingan_copy": "Your Sharingan copied %s!",
        "message.shinobiarts.already_known": "You already know %s.",
        "message.shinobiarts.wrong_clan": "Only the %s clan can learn this jutsu.",
        "message.shinobiarts.need_affinity": "Discover your nature affinity with Chakra Paper first.",
        "message.shinobiarts.need_nature": "You need %s to learn this. Train it with a Training Scroll.",
        "message.shinobiarts.need_level": "You must be level %s to learn this (you are level %s).",
        "message.shinobiarts.level_up": "Level up! You are now level %s: +%s stat points and %s Ryo. Press J to spend them.",
        "message.shinobiarts.xp_gained": "+%s XP",
        "message.shinobiarts.no_points": "You have no stat points left.",
        "message.shinobiarts.stat_capped": "That stat is already maxed.",
        "message.shinobiarts.nothing_to_reset": "You haven't spent any stat points.",
        "message.shinobiarts.not_enough_ryo": "Not enough Ryo (needs %s, you have %s).",
        "message.shinobiarts.stats_reset": "Your stats were reset for %s Ryo.",
        "message.shinobiarts.no_coins": "You have no coins to deposit.",
        "message.shinobiarts.deposited": "Deposited %s Ryo",
        "message.shinobiarts.full_health": "Already at full health.",
        "message.shinobiarts.sage_on": "Sage Mode!",
        "message.shinobiarts.sage_off": "Sage Mode ended",
        "message.shinobiarts.no_senjutsu": "Put points into Senjutsu (J) to use Sage Mode.",
        "message.shinobiarts.low_senjutsu": "Not enough natural energy (%s / %s). Hold Z while standing still to gather it.",
        "message.shinobiarts.learned": "You learned %s!",
        "message.shinobiarts.already_have_nature": "You already have %s.",
        "message.shinobiarts.nature_unlocked": "You can now learn %s jutsu!",
        "message.shinobiarts.affinity_known": "Your affinity is %s.",
        "message.shinobiarts.affinity_revealed": "Your nature affinity is %s! You can now learn its jutsu.",
        "message.shinobiarts.paper.fire": "The paper ignites and burns to ash...",
        "message.shinobiarts.paper.water": "The paper turns damp...",
        "message.shinobiarts.paper.wind": "The paper splits cleanly in two...",
        "message.shinobiarts.paper.lightning": "The paper wrinkles and crackles...",
        "message.shinobiarts.paper.earth": "The paper crumbles into dirt...",
        "message.shinobiarts.pill": "+%s chakra",
        "message.shinobiarts.substitution_ready": "Substitution set: the next hit will miss you.",
        "message.shinobiarts.substitution_used": "Substitution!",
        "message.shinobiarts.rasengan_ready": "Rasengan formed: punch something!",
        "message.shinobiarts.dodged": "Sharingan: dodged!",
        "message.shinobiarts.no_dojutsu": "Your clan has no eye technique.",
        "message.shinobiarts.dojutsu_on": "%s activated",
        "message.shinobiarts.dojutsu_off": "%s deactivated",
        "message.shinobiarts.welcome.clan": "You were born into the %s clan.",
        "message.shinobiarts.welcome.dojutsu": "Your bloodline carries the %s. Press V to activate it.",
        "message.shinobiarts.welcome.paper": "Craft Chakra Paper (paper + lapis lazuli) to discover your nature affinity.",
        "message.shinobiarts.welcome.keys": "Hold a release, right-click to cast and press G/H to move the jutsu arrow. J opens your stats, hold Z to charge chakra, Shift+Space to Ninja Jump.",

        "death.attack.shinobiarts.jutsu": "%1$s was struck down by a jutsu",
        "death.attack.shinobiarts.jutsu.player": "%1$s was struck down by %2$s's jutsu",
        "death.attack.shinobiarts.jutsu.item": "%1$s was struck down by %2$s's jutsu using %3$s",
        "death.attack.shinobiarts.amaterasu": "%1$s was consumed by black flames",
        "death.attack.shinobiarts.amaterasu.player": "%1$s was consumed by black flames while fighting %2$s",
        "death.attack.shinobiarts.amaterasu.item": "%1$s was consumed by black flames while fighting %2$s",
    }
    for n, name in NATURE_NAMES.items():
        lang["nature.shinobiarts." + n] = name
    for r, name in RANK_NAMES.items():
        lang["jutsu_rank.shinobiarts." + r.lower()] = name
    for n in NATURES:
        lang["item.shinobiarts.nature_scroll_" + n] = NATURE_NAMES[n] + " Training Scroll"
        item_3d("nature_scroll_" + n, "scroll_training_" + n, "scroll_training_" + n + "_icon")
    for r in RELEASES:
        lang["item.shinobiarts.release_" + r] = NATURE_NAMES[r] + " Scroll"
        item_model("release_" + r, "release_" + r)  # held as its octagon emblem

    seen_recipes = {}

    def track(name, key):
        assert key not in seen_recipes, f"recipe {name} has the same ingredients as {seen_recipes[key]}"
        seen_recipes[key] = name

    for j in jutsus:
        jid = j["id"]
        full, desc = JUTSU_TEXT[jid]
        lang["jutsu.shinobiarts." + jid] = full
        lang["jutsu.shinobiarts." + jid + ".desc"] = desc
        lang["item.shinobiarts.scroll_" + jid] = "Jutsu Scroll: " + short_name(full)
        release = "ninjutsu" if j["clan"] or j["nature"] == "none" else j["nature"]
        item_3d("scroll_" + jid, "scroll_jutsu_" + release, "scroll_jutsu_" + release + "_icon")
        if jid in SPECIAL_RECIPES:
            extra = SPECIAL_RECIPES[jid]
        else:
            extra = [CATALYST[j["nature"]]] * 2 + ([RECIPE_EXTRA[jid]] if RECIPE_EXTRA[jid] else [])
        track("scroll_" + jid, shapeless("scroll_" + jid, [MODID + ":blank_scroll"] + extra, MODID + ":scroll_" + jid))

    for n in NATURES:
        track("nature_scroll_" + n, shapeless("nature_scroll_" + n,
                  [MODID + ":blank_scroll"] + [CATALYST[n]] * 3 + ["minecraft:emerald"], MODID + ":nature_scroll_" + n))
    for r in RELEASES:
        track("release_" + r, shapeless("release_" + r, [MODID + ":blank_scroll"] + [CATALYST[r]] * 4, MODID + ":release_" + r))

    # Basic items
    track("blank_scroll", shapeless("blank_scroll", ["minecraft:paper"] * 3 + ["minecraft:stick"], MODID + ":blank_scroll"))
    track("chakra_paper", shapeless("chakra_paper", ["minecraft:paper", "minecraft:lapis_lazuli"], MODID + ":chakra_paper", 2))
    track("chakra_pill", shapeless("chakra_pill", ["minecraft:sugar", "minecraft:sweet_berries", "minecraft:glowstone_dust"],
                                   MODID + ":chakra_pill", 2))
    track("explosive_tag", shapeless("explosive_tag", ["minecraft:paper", "minecraft:gunpowder", "minecraft:redstone"],
                                     MODID + ":explosive_tag", 2, "equipment"))
    shaped("kunai", [" I", "S "], {"I": "minecraft:iron_ingot", "S": "minecraft:stick"}, MODID + ":kunai", 3)
    shaped("shuriken", [" N ", "NIN", " N "], {"N": "minecraft:iron_nugget", "I": "minecraft:iron_ingot"}, MODID + ":shuriken", 4)

    track("frog_wallet", shapeless("frog_wallet", ["minecraft:leather", "minecraft:leather", "minecraft:slime_ball",
                                                    "minecraft:lime_dye", "minecraft:string"], MODID + ":frog_wallet"))
    shaped("zabuza_blade", ["  B", " B ", "N  "], {"B": "minecraft:iron_block", "N": "minecraft:netherite_ingot"}, MODID + ":zabuza_blade")
    shaped("samehada", ["  H", " P ", "N  "], {"H": "minecraft:heart_of_the_sea", "P": "minecraft:prismarine",
                                               "N": "minecraft:netherite_ingot"}, MODID + ":samehada")
    shaped("hidan_scythe", ["III", " N ", "S  "], {"I": "minecraft:iron_block", "N": "minecraft:netherite_ingot",
                                                   "S": "minecraft:stick"}, MODID + ":hidan_scythe")
    shaped("sword_of_fire", ["  G", " N ", "R  "], {"G": "minecraft:gold_block", "N": "minecraft:netherite_ingot",
                                                    "R": "minecraft:blaze_rod"}, MODID + ":sword_of_fire")
    shaped("shakujo", ["  B", " G ", "G  "], {"B": "minecraft:bell", "G": "minecraft:gold_block"}, MODID + ":shakujo")
    shaped("kusanagi", ["  D", " D ", "S  "], {"D": "minecraft:diamond", "S": "minecraft:stick"}, MODID + ":kusanagi")
    shaped("sharingan", ["ERE"], {"E": "minecraft:ender_eye", "R": "minecraft:redstone_block"}, MODID + ":sharingan")
    shaped("katana", ["  I", " I ", "S  "], {"I": "minecraft:iron_ingot", "S": "minecraft:stick"}, MODID + ":katana")

    # 3D models (OBJ files come from tools/convert_models.py)
    obj_model("kunai", KUNAI_DISPLAY)
    for weapon, params in WEAPONS.items():
        obj_model(weapon, weapon_display(*params))
        item_3d(weapon, weapon, weapon + "_icon")
    obj_model("scroll_blank", SCROLL_DISPLAY)
    for n in NATURES:  # training scroll colors (textures and icons from tools/recolor_scrolls.py)
        obj_model("scroll_training_" + n, SCROLL_DISPLAY, obj="scroll_training", textures=[f"scroll_training_{n}"])
    for r in RELEASES:  # one color of jutsu scroll per release (textures from tools/recolor_scrolls.py)
        obj_model("scroll_jutsu_" + r, SCROLL_DISPLAY, obj="scroll_jutsu", textures=[f"scroll_jutsu_{r}"])
    item_3d("kunai", "kunai", "kunai_icon")
    obj_model("shuriken", HELD_ITEM)
    item_3d("shuriken", "shuriken", "shuriken_icon")
    item_3d("blank_scroll", "scroll_blank", "scroll_blank_icon")
    for name in ("sharingan", "sharingan_eye", "xp_boost_1_5x_30m", "xp_boost_1_5x_60m", "xp_boost_2_5x_30m",
                 "xp_boost_2_5x_60m", "explosive_tag", "chakra_pill", "chakra_paper", "exp_bottle", "frog_wallet",
                 "bronze_ryo", "silver_ryo", "gold_ryo"):
        item_model(name, name)

    # Earth wall block
    write_json(os.path.join(ASSETS, "blockstates", "earth_wall.json"), {"variants": {"": {"model": MODID + ":block/earth_wall"}}})
    write_json(os.path.join(ASSETS, "models", "block", "earth_wall.json"),
               {"parent": "minecraft:block/cube_all", "textures": {"all": MODID + ":block/earth_wall"}})

    # Damage types (for death messages)
    write_json(os.path.join(DATA, "damage_type", "jutsu.json"),
               {"exhaustion": 0.1, "message_id": "shinobiarts.jutsu", "scaling": "when_caused_by_living_non_player"})
    write_json(os.path.join(DATA, "damage_type", "amaterasu.json"),
               {"effects": "burning", "exhaustion": 0.0, "message_id": "shinobiarts.amaterasu", "scaling": "never"})

    write_json(os.path.join(ASSETS, "lang", "en_us.json"), dict(sorted(lang.items())))
    print(f"{len(jutsus)} jutsu, {len(lang)} lang keys, {len(seen_recipes) + 4 + len(WEAPONS)} recipes")


if __name__ == "__main__":
    main()
