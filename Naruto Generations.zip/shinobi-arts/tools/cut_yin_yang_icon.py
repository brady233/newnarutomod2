"""Cuts the provided yin-yang picture (tools/source_art/yin_yang.png) into the Yin Yang release icon.
Run: python3 tools/cut_yin_yang_icon.py, then python3 tools/make_textures.py"""
import math
import os
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, "source_art", "yin_yang.png")
OUT_DIR = os.path.join(HERE, "..", "src", "main", "resources", "assets", "shinobiarts", "textures", "nature")

im = Image.open(SRC).convert("RGBA")
w, h = im.size
dark = [(x, y) for y in range(h) for x in range(w) if sum(im.getpixel((x, y))[:3]) < 3 * 128]
x0, x1 = min(p[0] for p in dark), max(p[0] for p in dark)
y0, y1 = min(p[1] for p in dark), max(p[1] for p in dark)
cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
r = max(x1 - x0, y1 - y0) / 2 + 0.5
side = int(math.ceil(2 * r)) + 2
crop = Image.new("RGBA", (side, side), (0, 0, 0, 0))
for y in range(side):
    for x in range(side):
        sx, sy = int(cx - side / 2 + x), int(cy - side / 2 + y)
        if 0 <= sx < w and 0 <= sy < h and math.hypot(sx + 0.5 - cx, sy + 0.5 - cy) <= r:
            crop.putpixel((x, y), im.getpixel((sx, sy)))
# add a thin dark ring so the white half reads against light backgrounds
ring = Image.new("RGBA", crop.size, (0, 0, 0, 0))
for y in range(side):
    for x in range(side):
        d = math.hypot(x + 0.5 - side / 2, y + 0.5 - side / 2)
        if r - 4 <= d <= r:
            ring.putpixel((x, y), (20, 20, 20, 255))
crop = Image.alpha_composite(crop, ring)
os.makedirs(OUT_DIR, exist_ok=True)
crop.resize((64, 64), Image.LANCZOS).save(os.path.join(OUT_DIR, "yin_yang.png"))
open(os.path.join(OUT_DIR, ".yin_yang.provided"), "w").close()
print("yin_yang icon written")
